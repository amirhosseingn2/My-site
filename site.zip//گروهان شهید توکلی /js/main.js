// ==================== توابع اصلی ====================

// بارگذاری منو بر اساس نقش کاربر
function loadSidebar() {
    console.log("📋 در حال بارگذاری نوار کناری...");
    
    const user = getCurrentUser();
    if (!user) {
        console.log("🚫 کاربر وارد نشده، انتقال به صفحه ورود");
        window.location.href = 'index.html';
        return;
    }
    
    console.log("👤 کاربر برای منو:", user);
    
    let menuItems = '';
    
    // آیتم‌های مشترک برای همه
    menuItems += `
        <li>
            <a href="dashboard.html" class="${window.location.pathname.includes('dashboard.html') ? 'active' : ''}">
                <i class="fas fa-home"></i>
                صفحه اصلی
            </a>
        </li>
        <li>
            <a href="ration.html" class="${window.location.pathname.includes('ration.html') ? 'active' : ''}">
                <i class="fas fa-chart-bar"></i>
                آمار جیره
            </a>
        </li>
        <li>
            <a href="news.html" class="${window.location.pathname.includes('news.html') ? 'active' : ''}">
                <i class="fas fa-bullhorn"></i>
                اطلاع‌رسانی
            </a>
        </li>
        <li>
            <a href="chat.html" class="${window.location.pathname.includes('chat.html') ? 'active' : ''}">
                <i class="fas fa-comments"></i>
                چت کاربران
            </a>
        </li>
        <li>
            <a href="top-users.html" class="${window.location.pathname.includes('top-users.html') ? 'active' : ''}">
                <i class="fas fa-trophy"></i>
                نفرات برتر
            </a>
        </li>
        <li>
            <a href="events.html" class="${window.location.pathname.includes('events.html') ? 'active' : ''}">
                <i class="fas fa-calendar-alt"></i>
                رویدادها
            </a>
        </li>
        <li>
            <a href="dorms.html" class="${window.location.pathname.includes('dorms.html') ? 'active' : ''}">
                <i class="fas fa-home"></i>
                خوابگاه‌ها
            </a>
        </li>
    `;
    
    // منوی ادمین و منشی
    if (checkPermission('secretary')) {
        menuItems += `
            <li>
                <a href="punishments.html" class="${window.location.pathname.includes('punishments.html') ? 'active' : ''}">
                    <i class="fas fa-exclamation-triangle"></i>
                    تنبیهی‌ها
                </a>
            </li>
        `;
    }
    
    // منوی ادمین
    if (checkPermission('admin')) {
        menuItems += `
            <li>
                <a href="admin.html" class="${window.location.pathname.includes('admin.html') ? 'active' : ''}">
                    <i class="fas fa-cogs"></i>
                    بخش ادمین
                </a>
            </li>
        `;
    }
    
    // بخش منشی (اگر کاربر منشی باشد)
    if (user.role === 'secretary') {
        menuItems += `
            <li>
                <a href="secretary.html" class="${window.location.pathname.includes('secretary.html') ? 'active' : ''}">
                    <i class="fas fa-clipboard-list"></i>
                    بخش منشی
                </a>
            </li>
        `;
    }
    
    // حساب کاربری و خروج
    menuItems += `
        <li>
            <a href="profile.html" class="${window.location.pathname.includes('profile.html') ? 'active' : ''}">
                <i class="fas fa-user-circle"></i>
                حساب کاربری
            </a>
        </li>
        <li>
            <a href="#" onclick="logout(); return false;">
                <i class="fas fa-sign-out-alt"></i>
                خروج
            </a>
        </li>
    `;
    
    // ایجاد HTML نوار کناری
    const roleText = user.role === 'admin' ? 'مدیر سیستم' : 
                    user.role === 'secretary' ? 'منشی' : 'کاربر';
    
    const dormText = user.dormNumber === '0' ? 'بدون خوابگاه' : `خوابگاه ${user.dormNumber}`;
    
    const sidebarHTML = `
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>گروهان شهید توکلی</h2>
                <p>سیستم مدیریت داخلی</p>
            </div>
            
            <ul class="sidebar-menu">
                ${menuItems}
            </ul>
            
            <div class="user-info">
                <div class="user-avatar">
                    ${user.fullName ? user.fullName.charAt(0) : '?'}
                </div>
                <p class="user-name">${user.fullName || 'کاربر'}</p>
                <p class="user-role">${roleText}</p>
                <p class="user-dorm">${dormText}</p>
                <p class="user-department">${user.department || ''}</p>
            </div>
        </div>
    `;
    
    console.log("✅ نوار کناری ایجاد شد");
    document.body.innerHTML = sidebarHTML + document.body.innerHTML;
}

// ==================== توابع کمکی داشبورد ====================

// نمایش تاریخ شمسی
function getPersianDate() {
    const today = new Date();
    try {
        const options = { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            weekday: 'long'
        };
        return today.toLocaleDateString('fa-IR', options);
    } catch (e) {
        return today.toLocaleDateString('fa-IR');
    }
}

// نمایش اعلان
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `message ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        ${message}
    `;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        max-width: 300px;
        animation: slideInRight 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-out';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// بارگذاری اطلاعات اولیه داشبورد
function loadDashboard() {
    console.log("📊 در حال بارگذاری داشبورد...");
    
    if (!isLoggedIn()) {
        console.log("🚫 کاربر وارد نشده");
        window.location.href = 'index.html';
        return;
    }
    
    const user = getCurrentUser();
    console.log("👤 کاربر برای داشبورد:", user);
    
    if (!user) {
        console.log("❌ اطلاعات کاربر نامعتبر");
        logout();
        return;
    }
    
    const today = getPersianDate();
    
    // آپدیت هدر صفحه داشبورد
    const headerHTML = `
        <div class="content-header">
            <h1>خوش آمدید، ${user.fullName}</h1>
            <p>امروز ${today} است</p>
            
            <div class="stats">
                <div class="card-grid">
                    <div class="card">
                        <h3>آمار جیره</h3>
                        <p>مهلت ثبت: ${getRationDeadline()}</p>
                        <p>وضعیت: ${checkRationStatus()}</p>
                    </div>
                    <div class="card">
                        <h3>اخبار جدید</h3>
                        <p>تعداد: ${getNewsCount()} خبر</p>
                    </div>
                    <div class="card">
                        <h3>پیام‌های جدید</h3>
                        <p>در چت: ${getUnreadMessages()} پیام</p>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.querySelector('.main-content').innerHTML = headerHTML;
    console.log("✅ داشبورد بارگذاری شد");
}

// توابع کمکی
function getRationDeadline() {
    try {
        const deadline = JSON.parse(localStorage.getItem('rationDeadline'));
        if (!deadline) return 'تعیین نشده';
        return new Date(deadline).toLocaleDateString('fa-IR');
    } catch (e) {
        return 'تعیین نشده';
    }
}

function checkRationStatus() {
    try {
        const deadline = new Date(JSON.parse(localStorage.getItem('rationDeadline')));
        const now = new Date();
        return now > deadline ? 'پایان مهلت' : 'باز است';
    } catch (e) {
        return 'نامشخص';
    }
}

function getNewsCount() {
    try {
        const news = JSON.parse(localStorage.getItem('news'));
        return news ? news.length : 0;
    } catch (e) {
        return 0;
    }
}

function getUnreadMessages() {
    try {
        const messages = JSON.parse(localStorage.getItem('chatMessages'));
        return messages ? messages.length : 0;
    } catch (e) {
        return 0;
    }
}

// ==================== مدیریت رویدادهای صفحه ====================

// بارگذاری خودکار هنگام لود صفحه
document.addEventListener('DOMContentLoaded', function() {
    console.log("📄 DOM بارگذاری شد");
    
    // اگر در صفحه dashboard هستیم
    if (window.location.pathname.includes('dashboard.html')) {
        console.log("🎯 صفحه داشبورد تشخیص داده شد");
        
        if (!isLoggedIn()) {
            console.log("🚫 دسترسی غیرمجاز، انتقال به صفحه ورود");
            window.location.href = 'index.html';
            return;
        }
        
        // بارگذاری نوار کناری
        loadSidebar();
        
        // بعد از بارگذاری نوار کناری، محتوای داشبورد را بارگذاری کن
        setTimeout(() => {
            loadDashboardContent();
        }, 100);
    }
    
    // اگر در صفحات دیگر هستیم (به جز index.html)
    else if (!window.location.pathname.includes('index.html')) {
        console.log("📍 صفحه غیر از ورود تشخیص داده شد:", window.location.pathname);
        
        if (!isLoggedIn()) {
            console.log("🚫 دسترسی غیرمجاز، انتقال به صفحه ورود");
            window.location.href = 'index.html';
            return;
        }
        
        // بارگذاری نوار کناری برای صفحات دیگر
        loadSidebar();
    }
});

// ==================== تابع جدید برای بارگذاری محتوای داشبورد ====================
function loadDashboardContent() {
    console.log("🎨 در حال بارگذاری محتوای داشبورد...");
    
    const user = getCurrentUser();
    if (!user) {
        console.log("❌ کاربری یافت نشد");
        return;
    }
    
    const content = `
        <div class="content-header">
            <h1>سلام، ${user.fullName} 👋</h1>
            <p>به سیستم مدیریت گروهان شهید توکلی خوش آمدید. امروز ${getPersianDate()} است.</p>
        </div>
        
        <div class="sections-grid">
            <!-- آمار جیره -->
            <div class="section-card" onclick="navigateTo('ration.html')">
                <div class="section-icon">
                    <i class="fas fa-chart-bar"></i>
                </div>
                <h3>آمار جیره</h3>
                <p>ثبت و مشاهده آمار جیره هفتگی</p>
                <div class="section-stats">
                    <div class="stat-item">
                        <div class="stat-value">${getRationStatus()}</div>
                        <div class="stat-label">وضعیت</div>
                    </div>
                </div>
            </div>
            
            <!-- اطلاع‌رسانی -->
            <div class="section-card" onclick="navigateTo('news.html')">
                <div class="section-icon">
                    <i class="fas fa-bullhorn"></i>
                </div>
                        <h3>اطلاع‌رسانی</h3>
                <p>مشاهده آخرین اخبار و اطلاعیه‌ها</p>
                <div class="section-stats">
                    <div class="stat-item">
                        <div class="stat-value">${getNewsCount()}</div>
                        <div class="stat-label">اخبار جدید</div>
                    </div>
                </div>
            </div>
            
            <!-- چت کاربران -->
            <div class="section-card" onclick="navigateTo('chat.html')">
                <div class="section-icon">
                    <i class="fas fa-comments"></i>
                </div>
                <h3>چت کاربران</h3>
                <p>ارسال و دریافت پیام با سایر اعضا</p>
                <div class="section-stats">
                    <div class="stat-item">
                        <div class="stat-value">${getUnreadMessages()}</div>
                        <div class="stat-label">پیام جدید</div>
                    </div>
                </div>
            </div>
            
            <!-- نفرات برتر -->
            <div class="section-card" onclick="navigateTo('top-users.html')">
                <div class="section-icon">
                    <i class="fas fa-trophy"></i>
                </div>
                <h3>نفرات برتر</h3>
                <p>مشاهده نفرات برتر هر رشته و فعالیت</p>
            </div>
            
            <!-- رویدادها -->
            <div class="section-card" onclick="navigateTo('events.html')">
                <div class="section-icon">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <h3>رویدادها</h3>
                <p>برنامه مسابقات، کتابخوانی و سایر رویدادها</p>
                <div class="section-stats">
                    <div class="stat-item">
                        <div class="stat-value">${getEventsCount()}</div>
                        <div class="stat-label">رویداد فعال</div>
                    </div>
                </div>
            </div>
            
            <!-- خوابگاه‌ها -->
            <div class="section-card" onclick="navigateTo('dorms.html')">
                <div class="section-icon">
                    <i class="fas fa-home"></i>
                </div>
                <h3>خوابگاه‌ها</h3>
                <p>مشاهده اطلاعات خوابگاه‌ها و هم‌اتاقی‌ها</p>
                <div class="section-stats">
                    <div class="stat-item">
                        <div class="stat-value">${getDormNumber(user)}</div>
                        <div class="stat-label">خوابگاه شما</div>
                    </div>
                </div>
            </div>
            
            <!-- حساب کاربری -->
            <div class="section-card" onclick="navigateTo('profile.html')">
                <div class="section-icon">
                    <i class="fas fa-user-circle"></i>
                </div>
                <h3>حساب کاربری</h3>
                <p>مدیریت اطلاعات شخصی و تغییر رمز عبور</p>
            </div>
            
            <!-- بخش مدیریتی (فقط برای ادمین و منشی) -->
            ${user.role === 'admin' || user.role === 'secretary' ? `
            <div class="section-card" onclick="navigateTo('${user.role === 'admin' ? 'admin.html' : 'secretary.html'}')">
                <div class="section-icon" style="background: linear-gradient(135deg, #e74c3c, #c0392b);">
                    <i class="fas fa-cogs"></i>
                </div>
                <h3>${user.role === 'admin' ? 'پنل مدیریت' : 'بخش منشی'}</h3>
                <p>${user.role === 'admin' ? 'مدیریت کامل سیستم' : 'مدیریت بخش‌های اختصاصی'}</p>
            </div>
            ` : ''}
        </div>
        
        <!-- اعلان‌ها -->
        <div class="notifications">
            <h2 style="color: #2c3e50; margin-bottom: 20px;">📢 اعلان‌های مهم</h2>
            
            <div class="notification-item">
                <div class="notification-icon">
                    <i class="fas fa-bell"></i>
                </div>
                <div class="notification-content">
                    <h4>مهلت ثبت آمار جیره</h4>
                    <p>${getRationDeadlineMessage()}</p>
                    <div class="notification-time">آخرین بروزرسانی: امروز</div>
                </div>
            </div>
            
            <div class="notification-item">
                <div class="notification-icon">
                    <i class="fas fa-info-circle"></i>
                </div>
                <div class="notification-content">
                    <h4>دستورالعمل استفاده از سیستم</h4>
                    <p>لطفاً بخش راهنما را برای آشنایی با امکانات سیستم مطالعه فرمایید.</p>
                    <div class="notification-time">همیشه</div>
                </div>
            </div>
        </div>
    `;
    
    const mainContent = document.querySelector('.main-content');
    if (mainContent) {
        mainContent.innerHTML = content;
        console.log("✅ محتوای داشبورد بارگذاری شد");
    } else {
        console.log("❌ المان .main-content یافت نشد");
    }
}

// ==================== توابع جدید برای داشبورد ====================
function navigateTo(page) {
    console.log("🔄 انتقال به صفحه:", page);
    window.location.href = page;
}

function getEventsCount() {
    try {
        const events = JSON.parse(localStorage.getItem('events'));
        return events ? events.length : 0;
    } catch (e) {
        return 0;
    }
}

function getDormNumber(user) {
    return user.dormNumber === '0' ? 'تعیین نشده' : user.dormNumber;
}

function getRationDeadlineMessage() {
    try {
        const deadline = new Date(JSON.parse(localStorage.getItem('rationDeadline')));
        if (!deadline) return 'مهلتی تعیین نشده است';
        
        const now = new Date();
        if (now > deadline) {
            return 'مهلت ثبت آمار جیره به پایان رسیده است.';
        } else {
            const persianDate = deadline.toLocaleDateString('fa-IR');
            const time = deadline.toLocaleTimeString('fa-IR', {hour: '2-digit', minute:'2-digit'});
            return `آخرین مهلت ثبت: ${persianDate} ساعت ${time}`;
        }
    } catch (e) {
        return 'مهلتی تعیین نشده است';
    }
}

// اضافه کردن استایل‌های انیمیشن
document.head.insertAdjacentHTML('beforeend', `
    <style>
        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOutRight {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
        
        .sections-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
            margin-top: 20px;
        }
        
        .section-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            transition: all 0.3s;
            border: 2px solid transparent;
            text-align: center;
            cursor: pointer;
        }
        
        .section-card:hover {
            transform: translateY(-10px);
            border-color: #3498db;
            box-shadow: 0 15px 35px rgba(52, 152, 219, 0.15);
        }
        
        .section-icon {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: linear-gradient(135deg, #3498db, #2980b9);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 30px;
            color: white;
        }
        
        .section-stats {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-value {
            font-weight: bold;
            color: #3498db;
            font-size: 1.2rem;
        }
        
        .stat-label {
            font-size: 0.85rem;
            color: #7f8c8d;
        }
        
        .notifications {
            margin-top: 30px;
        }
        
        .notification-item {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 15px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
            border-right: 4px solid #3498db;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .notification-icon {
            color: #3498db;
            font-size: 1.5rem;
        }
        
        .notification-content h4 {
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .notification-content p {
            color: #7f8c8d;
            font-size: 0.9rem;
        }
        
        .notification-time {
            font-size: 0.8rem;
            color: #95a5a6;
        }
    </style>
`);