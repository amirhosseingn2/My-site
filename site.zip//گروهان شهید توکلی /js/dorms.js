// ==================== مدیریت صفحه خوابگاه‌ها ====================

// داده‌های اولیه
let allUsers = [];
let dormsData = {};
let currentUser = null;

// ==================== بارگذاری اولیه ====================
document.addEventListener('DOMContentLoaded', function() {
    console.log("🏢 صفحه خوابگاه‌ها بارگذاری شد");
    
    // بررسی ورود کاربر
    checkUserAccess();
    
    // بارگذاری داده‌ها
    loadDormsData();
    
    // تنظیم رویدادها
    setupEventListeners();
});

// بررسی دسترسی کاربر
function checkUserAccess() {
    const userData = localStorage.getItem('currentUser');
    if (!userData) {
        window.location.href = 'index.html';
        return;
    }
    
    currentUser = JSON.parse(userData);
    console.log("👤 کاربر:", currentUser.username);
}

// بارگذاری داده‌های خوابگاه‌ها
function loadDormsData() {
    // بارگذاری کاربران
    allUsers = JSON.parse(localStorage.getItem('users') || '[]');
    
    // بارگذاری اطلاعات خوابگاه‌ها
    dormsData = JSON.parse(localStorage.getItem('dormsData') || '{}');
    
    // اگر داده‌ای نیست، نمونه ایجاد کن
    if (Object.keys(dormsData).length === 0) {
        createSampleDormsData();
    }
    
    console.log(`👥 ${allUsers.length} کاربر بارگذاری شد`);
    
    // نمایش داده‌ها
    displayDormsStats();
    displayDormsList();
    updateDistributionChart();
}

// ایجاد داده‌های نمونه
function createSampleDormsData() {
    // اطلاعات خوابگاه‌ها
    dormsData = {
        dorm1: {
            name: "خوابگاه ۱ - امیرکبیر",
            capacity: 30,
            description: "خوابگاه مخصوص دانشجویان رشته‌های مهندسی",
            supervisor: {
                name: "سید محمد حسینی",
                username: "supervisor1",
                role: "سرپرست خوابگاه"
            },
            residents: []
        },
        dorm2: {
            name: "خوابگاه ۲ - شهید چمران",
            capacity: 35,
            description: "خوابگاه دانشجویان علوم پایه و انسانی",
            supervisor: {
                name: "علی کریمی",
                username: "supervisor2",
                role: "سرپرست خوابگاه"
            },
            residents: []
        },
        dorm3: {
            name: "خوابگاه ۳ - دکتر حسابی",
            capacity: 25,
            description: "خوابگاه دانشجویان ممتاز",
            supervisor: {
                name: "مهدی نوری",
                username: "supervisor3",
                role: "سرپرست خوابگاه"
            },
            residents: []
        },
        dorm4: {
            name: "خوابگاه ۴ - شهید بابایی",
            capacity: 40,
            description: "خوابگاه عمومی گروهان",
            supervisor: {
                name: "رضا قربانی",
                username: "supervisor4",
                role: "سرپرست خوابگاه"
            },
            residents: []
        }
    };
    
    // توزیع تصادفی کاربران در خوابگاه‌ها
    distributeUsersToDorms();
    
    localStorage.setItem('dormsData', JSON.stringify(dormsData));
    console.log("✅ داده‌های نمونه خوابگاه‌ها ایجاد شدند");
}

// توزیع کاربران در خوابگاه‌ها
function distributeUsersToDorms() {
    // پاک کردن ساکنین قبلی
    for (let dorm in dormsData) {
        dormsData[dorm].residents = [];
    }
    
    // کاربران عادی (نه ادمین و منشی)
    const regularUsers = allUsers.filter(user => 
        user.role === 'user' && user.isActive !== false
    );
    
    // توزیع تصادفی
    regularUsers.forEach((user, index) => {
        const dormNumber = (index % 4) + 1; // توزیع متوازن
        const dormKey = `dorm${dormNumber}`;
        
        dormsData[dormKey].residents.push({
            username: user.username,
            fullName: user.fullName,
            department: user.department,
            studentId: user.studentId,
            avatar: user.fullName.charAt(0)
        });
        
        // به‌روزرسانی شماره خوابگاه کاربر
        user.dormNumber = dormNumber.toString();
    });
    
    // ذخیره کاربران به‌روزرسانی شده
    localStorage.setItem('users', JSON.stringify(allUsers));
}

// تنظیم رویدادها
function setupEventListeners() {
    // دکمه به‌روزرسانی
    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            loadDormsData();
            showNotification('اطلاعات خوابگاه‌ها به‌روزرسانی شد', 'success');
        });
    }
    
    // کلیک روی کارت‌های آمار
    const statCards = document.querySelectorAll('.dorm-stat-card');
    statCards.forEach(card => {
        card.addEventListener('click', function() {
            const dormNumber = this.getAttribute('data-dorm');
            scrollToDorm(dormNumber);
        });
    });
}

// نمایش آمار خوابگاه‌ها
function displayDormsStats() {
    for (let i = 1; i <= 4; i++) {
        const dormKey = `dorm${i}`;
        const count = dormsData[dormKey]?.residents?.length || 0;
        document.getElementById(`dorm${i}Count`).textContent = count;
    }
}

// نمایش لیست خوابگاه‌ها
function displayDormsList() {
    const listContainer = document.getElementById('dormsList');
    if (!listContainer) return;
    
    let dormsHTML = '';
    
    for (let i = 1; i <= 4; i++) {
        const dormKey = `dorm${i}`;
        const dorm = dormsData[dormKey];
        if (!dorm) continue;
        
        const residents = dorm.residents || [];
        const capacity = dorm.capacity || 30;
        const percentage = Math.round((residents.length / capacity) * 100);
        
        // رنگ‌های مختلف برای خوابگاه‌ها
        const dormColors = {
            1: { header: 'dorm-1', color: '#3498db' },
            2: { header: 'dorm-2', color: '#27ae60' },
            3: { header: 'dorm-3', color: '#e74c3c' },
            4: { header: 'dorm-4', color: '#f39c12' }
        };
        
        let residentsHTML = '';
        
        if (residents.length === 0) {
            residentsHTML = `
                <div class="empty-residents">
                    <i class="fas fa-bed"></i>
                    <p>این خوابگاه در حال حاضر خالی است</p>
                </div>
            `;
        } else {
            residents.forEach(resident => {
                residentsHTML += `
                    <div class="resident-item">
                        <div class="resident-avatar" style="background: ${dormColors[i].color}">
                            ${resident.avatar}
                        </div>
                        <div class="resident-info">
                            <div class="resident-name">${resident.fullName}</div>
                            <div class="resident-details">
                                <span>${resident.studentId || 'بدون کد'}</span>
                                <span class="resident-major">${resident.department || 'بدون رشته'}</span>
                            </div>
                        </div>
                    </div>
                `;
            });
        }
        
        dormsHTML += `
            <div class="dorm-card" id="dorm${i}">
                <div class="dorm-card-header ${dormColors[i].header}">
                    <div class="dorm-number">${i}</div>
                    <h3 class="dorm-card-title">${dorm.name}</h3>
                    <p class="dorm-card-desc">${dorm.description}</p>
                </div>
                
                <div class="dorm-card-content">
                    <div class="dorm-info">
                        <div class="dorm-info-item">
                            <span class="dorm-info-label">ظرفیت:</span>
                            <span class="dorm-info-value">${residents.length}/${capacity} نفر</span>
                        </div>
                        <div class="dorm-info-item">
                            <span class="dorm-info-label">اشغالی:</span>
                            <span class="dorm-info-value">${percentage}%</span>
                        </div>
                        <div class="dorm-info-item">
                            <span class="dorm-info-label">وضعیت:</span>
                            <span class="dorm-info-value">${percentage >= 90 ? 'پر' : percentage >= 70 ? 'نیمه پر' : 'نسبتاً خالی'}</span>
                        </div>
                    </div>
                    
                    <div class="residents-list">
                        ${residentsHTML}
                    </div>
                    
                    ${dorm.supervisor ? `
                        <div class="dorm-supervisor">
                            <div class="supervisor-avatar" style="background: ${dormColors[i].color}">
                                ${dorm.supervisor.name.charAt(0)}
                            </div>
                            <div class="supervisor-info">
                                <h4>${dorm.supervisor.name}</h4>
                                <p>${dorm.supervisor.role}</p>
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    }
    
    listContainer.innerHTML = dormsHTML;
}

// به‌روزرسانی نمودار توزیع
function updateDistributionChart() {
    const totalResidents = Object.values(dormsData).reduce((sum, dorm) => 
        sum + (dorm.residents?.length || 0), 0
    );
    
    let chartHTML = '';
    const chartLabels = document.querySelectorAll('.chart-label');
    
    for (let i = 1; i <= 4; i++) {
        const dormKey = `dorm${i}`;
        const count = dormsData[dormKey]?.residents?.length || 0;
        const percentage = totalResidents > 0 ? Math.round((count / totalResidents) * 100) : 25;
        
        // نمودار
        chartHTML += `<div class="chart-bar dorm-${i}" style="width: ${percentage}%">${percentage}%</div>`;
        
        // درصدها
        document.getElementById(`dorm${i}Percent`).textContent = `${percentage}%`;
    }
    
    document.getElementById('chartBars').innerHTML = chartHTML;
}

// نمایش جزئیات خوابگاه
function showDormDetails(dormNumber) {
    const dormKey = `dorm${dormNumber}`;
    const dorm = dormsData[dormKey];
    if (!dorm) return;
    
    const residents = dorm.residents || [];
    const capacity = dorm.capacity || 30;
    const percentage = Math.round((residents.length / capacity) * 100);
    
    let details = `
        🏢 ${dorm.name}
        
        📝 توضیحات:
        ${dorm.description}
        
        📊 آمار:
        • ساکنین: ${residents.length} نفر از ${capacity} نفر
        • درصد اشغالی: ${percentage}%
        • وضعیت: ${percentage >= 90 ? 'پر' : percentage >= 70 ? 'نیمه پر' : 'نسبتاً خالی'}
        
        👤 سرپرست:
        ${dorm.supervisor?.name || 'تعیین نشده'}
        ${dorm.supervisor?.role || ''}
    `;
    
    if (residents.length > 0) {
        details += '\n\n👥 لیست ساکنین:\n';
        residents.forEach((resident, index) => {
            details += `${index + 1}. ${resident.fullName} (${resident.department || 'بدون رشته'})\n`;
        });
    }
    
    alert(details);
}

// اسکرول به خوابگاه خاص
function scrollToDorm(dormNumber) {
    const dormElement = document.getElementById(`dorm${dormNumber}`);
    if (dormElement) {
        dormElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // انیمیشن هایلایت
        dormElement.style.animation = 'highlightPulse 1s ease';
        setTimeout(() => {
            dormElement.style.animation = '';
        }, 1000);
    }
}

// نمایش اعلان
function showNotification(text, type = 'info') {
    const oldNotification = document.querySelector('.notification');
    if (oldNotification) oldNotification.remove();
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: ${type === 'success' ? '#27ae60' : 
                    type === 'error' ? '#e74c3c' : 
                    type === 'warning' ? '#f39c12' : '#3498db'};
        color: white;
        padding: 12px 24px;
        border-radius: 8px;
        font-size: 14px;
        z-index: 2000;
        animation: slideDown 0.3s ease-out;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        display: flex;
        align-items: center;
        gap: 10px;
    `;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        info: 'fa-info-circle',
        warning: 'fa-exclamation-triangle'
    };
    
    notification.innerHTML = `
        <i class="fas ${icons[type]}"></i>
        <span>${text}</span>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(-50%) translateY(-10px)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }
    }, 3000);
}

// استایل‌های اضافی
const dormsStyles = `
    <style>
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateX(-50%) translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(-50%) translateY(0);
            }
        }
        
        @keyframes highlightPulse {
            0% { box-shadow: 0 0 0 0 rgba(52, 152, 219, 0.7); }
            70% { box-shadow: 0 0 0 20px rgba(52, 152, 219, 0); }
            100% { box-shadow: 0 0 0 0 rgba(52, 152, 219, 0); }
        }
        
        .dorm-card {
            animation: fadeInUp 0.5s ease-out;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
`;

document.head.insertAdjacentHTML('beforeend', dormsStyles);