// auth.js
const initializeAuth = () => {
    if (!localStorage.getItem('users')) {
        const defaultUsers = [
            {
                id: 1,
                fullName: "مدیر سیستم",
                username: "admin",
                password: "admin123",
                dormNumber: "0",
                role: "admin",
                department: "مدیریت",
                isActive: true
            },
            {
                id: 2,
                fullName: "منشی نمونه",
                username: "secretary",
                password: "secret123",
                dormNumber: "0",
                role: "secretary",
                department: "منشی",
                isActive: true
            },
            {
                id: 3,
                fullName: "سرباز نمونه",
                username: "user1",
                password: "user123",
                dormNumber: "1",
                role: "user",
                department: "مخابرات",
                isActive: true
            }
        ];
        localStorage.setItem('users', JSON.stringify(defaultUsers));
    }
};

const authenticateUser = (username, password) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.username === username && u.password === password && u.isActive);
    
    if (user) {
        const sessionUser = {
            id: user.id,
            fullName: user.fullName,
            username: user.username,
            dormNumber: user.dormNumber,
            role: user.role,
            department: user.department
        };
        localStorage.setItem('currentUser', JSON.stringify(sessionUser));
        return { success: true, user: sessionUser };
    }
    return { success: false, message: "نام کاربری یا رمز عبور اشتباه است" };
};

const logout = () => {
    localStorage.removeItem('currentUser');
    window.location.href = 'index.html';
};

const getCurrentUser = () => {
    return JSON.parse(localStorage.getItem('currentUser') || 'null');
};

const checkPermission = (requiredRole) => {
    const user = getCurrentUser();
    if (!user) return false;
    
    if (requiredRole === 'admin') {
        return user.role === 'admin';
    }
    if (requiredRole === 'secretary') {
        return user.role === 'admin' || user.role === 'secretary';
    }
    return true;
};