// مدیریت پروفایل کاربر
function loadProfilePage() {
    if (!isLoggedIn()) {
        window.location.href = 'index.html';
        return;
    }
    
    const user = getCurrentUser();
    
    const content = `
        <div class="content-header">
            <h1>حساب کاربری</h1>
            <p>مدیریت اطلاعات شخصی</p>
        </div>
        
        <div class="card-grid">
            <div class="card">
                <h3>اطلاعات کاربری</h3>
                <p><strong>نام کامل:</strong> ${user.fullName}</p>
                <p><strong>نام کاربری:</strong> ${user.username}</p>
                <p><strong>خوابگاه:</strong> ${user.dormNumber}</p>
                <p><strong>نقش:</strong> ${user.role === 'admin' ? 'مدیر' : 
                                           user.role === 'secretary' ? 'منشی' : 'کاربر'}</p>
                <p><strong>رشته:</strong> ${user.department || 'ثبت نشده'}</p>
            </div>
            
            <div class="card">
                <h3>تغییر رمز عبور</h3>
                <form id="changePasswordForm">
                    <div class="input-group">
                        <label for="currentPassword">رمز عبور فعلی</label>
                        <input type="password" id="currentPassword" required>
                    </div>
                    
                    <div class="input-group">
                        <label for="newPassword">رمز عبور جدید</label>
                        <input type="password" id="newPassword" required minlength="6">
                    </div>
                    
                    <div class="input-group">
                        <label for="confirmPassword">تکرار رمز عبور جدید</label>
                        <input type="password" id="confirmPassword" required>
                    </div>
                    
                    <button type="submit" class="btn-primary">تغییر رمز عبور</button>
                </form>
                <div id="passwordMessage"></div>
            </div>
        </div>
    `;
    
    document.querySelector('.main-content').innerHTML = content;
    
    // مدیریت فرم تغییر رمز
    document.getElementById('changePasswordForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const currentPass = document.getElementById('currentPassword').value;
        const newPass = document.getElementById('newPassword').value;
        const confirmPass = document.getElementById('confirmPassword').value;
        
        if (newPass !== confirmPass) {
            document.getElementById('passwordMessage').innerHTML = 
                '<div class="message error">رمز عبور جدید و تکرار آن مطابقت ندارند</div>';
            return;
        }
        
        if (newPass.length < 6) {
            document.getElementById('passwordMessage').innerHTML = 
                '<div class="message error">رمز عبور جدید باید حداقل ۶ کاراکتر باشد</div>';
            return;
        }
        
        const result = changePassword(user.username, currentPass, newPass);
        
        if (result.success) {
            document.getElementById('passwordMessage').innerHTML = 
                '<div class="message success">رمز عبور با موفقیت تغییر یافت</div>';
            
            // پاک کردن فیلدها
            document.getElementById('changePasswordForm').reset();
        } else {
            document.getElementById('passwordMessage').innerHTML = 
                `<div class="message error">${result.message}</div>`;
        }
    });
}

// بارگذاری صفحه پروفایل
document.addEventListener('DOMContentLoaded', function() {
    const path = window.location.pathname;
    if (path.includes('profile.html')) {
        loadProfilePage();
    }
});