// ==================== مدیریت صفحه رویدادها ====================

// داده‌های اولیه
let allEvents = [];
let currentCategory = 'all';
let currentUser = null;

// ==================== بارگذاری اولیه ====================
document.addEventListener('DOMContentLoaded', function() {
    console.log("📅 صفحه رویدادها بارگذاری شد");
    
    // بررسی ورود کاربر
    checkUserAccess();
    
    // بارگذاری داده‌ها
    loadEventsData();
    
    // تنظیم رویدادها
    setupEventListeners();
});

// بررسی دسترسی کاربر
function checkUserAccess() {
    const userData = localStorage.getItem('currentUser');
    if (!userData) {
        window.location.href = 'index.html';
        return;
    }
    
    currentUser = JSON.parse(userData);
    console.log("👤 کاربر:", currentUser.username);
}

// بارگذاری داده‌های رویدادها
function loadEventsData() {
    // بارگذاری از localStorage
    allEvents = JSON.parse(localStorage.getItem('eventsData') || '[]');
    
    // اگر داده‌ای نیست، نمونه ایجاد کن
    if (allEvents.length === 0) {
        createSampleEvents();
    }
    
    console.log(`📅 ${allEvents.length} رویداد بارگذاری شد`);
    
    // نمایش رویدادها
    displayEvents();
    updateStats();
}

// ایجاد رویدادهای نمونه
function createSampleEvents() {
    const sampleEvents = [
        {
            id: 1,
            category: 'competition',
            title: 'مسابقات برنامه‌نویسی گروهان',
            description: 'مسابقه برنامه‌نویسی با موضوع الگوریتم‌های پیشرفته و هوش مصنوعی برای دانشجویان رشته کامپیوتر و سایبر. این مسابقه در دو مرحله مقدماتی و نهایی برگزار می‌شود.',
            details: [
                'زمان: ۱۴۰۳/۰۱/۲۵ ساعت ۱۰ صبح',
                'مکان: آزمایشگاه کامپیوتر ساختمان مرکزی',
                'شرایط شرکت: دانشجویان رشته‌های کامپیوتر، سایبر و IT',
                'جوایز: مدال طلا، نقره و برنز به همراه هدایای نقدی'
            ],
            organizer: 'کمیته علمی گروهان',
            startDate: '2024-04-15',
            endDate: '2024-04-20',
            participants: 42,
            status: 'upcoming',
            importance: 'high',
            createdAt: new Date().toISOString()
        },
        {
            id: 2,
            category: 'reading',
            title: 'کتابخوانی ماهانه - دفاع مقدس',
            description: 'برنامه کتابخوانی با موضوع دفاع مقدس و ایثارگری. کتاب این ماه "دا" اثر سیده اعظم حسینی است.',
            details: [
                'کتاب: دا - خاطرات سیده اعظم حسینی',
                'زمان ارائه: ۱۴۰۳/۰۱/۲۰ ساعت ۱۶',
                'مکان: کتابخانه مرکزی گروهان',
                'شرکت برای عموم آزاد است'
            ],
            organizer: 'کمیته فرهنگی',
            startDate: '2024-03-20',
            endDate: '2024-04-20',
            participants: 28,
            status: 'ongoing',
            importance: 'medium',
            createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
            id: 3,
            category: 'sports',
            title: 'مسابقات فوتسال بین خوابگاهی',
            description: 'مسابقات فوتسال بین خوابگاه‌های گروهان با حضور ۸ تیم در دو گروه برگزار می‌شود.',
            details: [
                'زمان: هر روز ساعت ۱۸ عصر',
                'مکان: سالن ورزشی گروهان',
                'تیم‌ها: هر خوابگاه یک تیم',
                'جوایز: جام قهرمانی و مدال'
            ],
            organizer: 'کمیته ورزشی',
            startDate: '2024-03-25',
            endDate: '2024-04-10',
            participants: 64,
            status: 'ongoing',
            importance: 'high',
            createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
            id: 4,
            category: 'cultural',
            title: 'همایش سبک زندگی اسلامی',
            description: 'همایش یک روزه با موضوع سبک زندگی اسلامی و بررسی چالش‌های پیش روی جوانان در جامعه امروز.',
            details: [
                'سخنرانان: اساتید حوزه و دانشگاه',
                'زمان: ۱۴۰۳/۰۱/۳۰ ساعت ۹ صبح',
                'مکان: سالن اجتماعات ساختمان مرکزی',
                'گواهی حضور ارائه می‌شود'
            ],
            organizer: 'امور فرهنگی',
            startDate: '2024-04-30',
            endDate: '2024-04-30',
            participants: 0,
            status: 'upcoming',
            importance: 'medium',
            createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
            id: 5,
            category: 'educational',
            title: 'کارگاه امنیت سایبری',
            description: 'کارگاه آموزشی دو روزه با موضوع امنیت سایبری، آشنایی با تهدیدات و راه‌های مقابله.',
            details: [
                'مدرس: استاد احمدی',
                'زمان: ۱۴۰۳/۰۲/۰۵ و ۰۶',
                'مکان: کلاس ۱۰۲ ساختمان علوم',
                'پیش‌نیاز: آشنایی مقدماتی با شبکه'
            ],
            organizer: 'گروه سایبر',
            startDate: '2024-04-25',
            endDate: '2024-04-26',
            participants: 35,
            status: 'upcoming',
            importance: 'medium',
            createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
            id: 6,
            category: 'competition',
            title: 'مسابقات تیراندازی',
            description: 'مسابقه تیراندازی با سلاح‌های بادی برای دانشجویان گروهان. این مسابقه در سه مرحله برگزار می‌شود.',
            details: [
                'زمان: ۱۴۰۳/۰۲/۱۵',
                'مکان: میدان تیر گروهان',
                'شرایط: گذراندن دوره ایمنی',
                'جوایز: مدال و گواهی مهارت'
            ],
            organizer: 'امور نظامی',
            startDate: '2024-05-05',
            endDate: '2024-05-05',
            participants: 22,
            status: 'upcoming',
            importance: 'high',
            createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
        }
    ];
    
    allEvents = sampleEvents;
    localStorage.setItem('eventsData', JSON.stringify(sampleEvents));
    console.log("✅ رویدادهای نمونه ایجاد شدند");
}

// تنظیم رویدادها
function setupEventListeners() {
    // تب‌ها
    const eventTabs = document.querySelectorAll('.event-tab');
    eventTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // حذف کلاس active از همه
            eventTabs.forEach(t => t.classList.remove('active'));
            // اضافه کردن به دکمه کلیک شده
            this.classList.add('active');
            
            // اعمال فیلتر
            currentCategory = this.getAttribute('data-category');
            filterEvents();
        });
    });
    
    // فیلتر وضعیت
    const statusFilter = document.getElementById('statusFilter');
    if (statusFilter) {
        statusFilter.addEventListener('change', filterEvents);
    }
    
    // فیلتر تاریخ
    const dateFilter = document.getElementById('dateFilter');
    if (dateFilter) {
        dateFilter.addEventListener('change', filterEvents);
    }
    
    // جستجو
    const searchInput = document.getElementById('searchEvents');
    if (searchInput) {
        searchInput.addEventListener('input', filterEvents);
    }
    
    // دکمه به‌روزرسانی
    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            loadEventsData();
            showNotification('لیست رویدادها به‌روزرسانی شد', 'success');
        });
    }
}

// فیلتر رویدادها
function filterEvents() {
    const statusFilter = document.getElementById('statusFilter').value;
    const dateFilter = document.getElementById('dateFilter').value;
    const searchTerm = document.getElementById('searchEvents').value.toLowerCase();
    
    let filtered = allEvents;
    
    // فیلتر دسته
    if (currentCategory !== 'all') {
        filtered = filtered.filter(event => event.category === currentCategory);
    }
    
    // فیلتر وضعیت
    if (statusFilter !== 'all') {
        filtered = filtered.filter(event => event.status === statusFilter);
    }
    
    // فیلتر تاریخ
    if (dateFilter !== 'all') {
        const now = new Date();
        filtered = filtered.filter(event => {
            const eventDate = new Date(event.startDate);
            
            switch(dateFilter) {
                case 'today':
                    return eventDate.toDateString() === now.toDateString();
                case 'week':
                    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                    return eventDate >= weekAgo;
                case 'month':
                    const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
                    return eventDate >= monthAgo;
                default:
                    return true;
            }
        });
    }
    
    // فیلتر جستجو
    if (searchTerm) {
        filtered = filtered.filter(event =>
            event.title.toLowerCase().includes(searchTerm) ||
            event.description.toLowerCase().includes(searchTerm) ||
            event.organizer.toLowerCase().includes(searchTerm)
        );
    }
    
    // نمایش نتایج
    displayEvents(filtered);
    
    // نمایش/مخفی کردن حالت خالی
    const emptyState = document.getElementById('emptyState');
    if (emptyState) {
        emptyState.style.display = filtered.length === 0 ? 'block' : 'none';
    }
}

// نمایش رویدادها
function displayEvents(events = allEvents) {
    const listContainer = document.getElementById('eventsList');
    if (!listContainer) return;
    
    if (events.length === 0) {
        listContainer.innerHTML = '';
        return;
    }
    
    // مرتب‌سازی بر اساس اهمیت و تاریخ
    const sortedEvents = [...events].sort((a, b) => {
        // اولویت‌بندی بر اساس اهمیت
        const importanceOrder = { high: 1, medium: 2, low: 3 };
        if (importanceOrder[a.importance] !== importanceOrder[b.importance]) {
            return importanceOrder[a.importance] - importanceOrder[b.importance];
        }
        
        // سپس بر اساس تاریخ شروع
        return new Date(a.startDate) - new Date(b.startDate);
    });
    
    let eventsHTML = '';
    
    sortedEvents.forEach(event => {
        // آیکون و رنگ دسته
        let categoryConfig = {
            icon: 'fa-calendar',
            class: 'educational'
        };
        
        switch(event.category) {
            case 'competition':
                categoryConfig = { icon: 'fa-trophy', class: 'competition' };
                break;
            case 'reading':
                categoryConfig = { icon: 'fa-book-open', class: 'reading' };
                break;
            case 'cultural':
                categoryConfig = { icon: 'fa-theater-masks', class: 'cultural' };
                break;
            case 'sports':
                categoryConfig = { icon: 'fa-futbol', class: 'sports' };
                break;
            case 'educational':
                categoryConfig = { icon: 'fa-graduation-cap', class: 'educational' };
                break;
        }
        
        // وضعیت رویداد
        let statusConfig = {
            text: 'پیش‌رو',
            class: 'status-upcoming'
        };
        
        switch(event.status) {
            case 'ongoing':
                statusConfig = { text: 'در حال برگزاری', class: 'status-ongoing' };
                break;
            case 'completed':
                statusConfig = { text: 'پایان یافته', class: 'status-completed' };
                break;
        }
        
        // تاریخ شروع و پایان
        const startDate = new Date(event.startDate);
        const endDate = new Date(event.endDate);
        const startDateStr = startDate.toLocaleDateString('fa-IR');
        const endDateStr = endDate.toLocaleDateString('fa-IR');
        
        eventsHTML += `
            <div class="event-card">
                <div class="event-header ${categoryConfig.class}">
                    <div class="event-category">
                        <i class="fas ${categoryConfig.icon}"></i>
                        ${getCategoryName(event.category)}
                    </div>
                    <h3 class="event-title">${event.title}</h3>
                    <div class="event-icon">
                        <i class="fas ${categoryConfig.icon}"></i>
                    </div>
                </div>
                
                <div class="event-content">
                    <div class="event-meta">
                        <div class="meta-item">
                            <i class="fas fa-calendar"></i>
                            <span>${startDateStr}${startDateStr !== endDateStr ? ` تا ${endDateStr}` : ''}</span>
                        </div>
                        <div class="meta-item">
                            <i class="fas fa-users"></i>
                            <span>${event.participants} شرکت‌کننده</span>
                        </div>
                        <div class="meta-item">
                            <i class="fas fa-user-tie"></i>
                            <span>${event.organizer}</span>
                        </div>
                    </div>
                    
                    <div class="event-description">
                        ${formatEventDescription(event.description)}
                    </div>
                    
                    <div class="event-details">
                        <h4 class="details-title">
                            <i class="fas fa-info-circle"></i>
                            جزئیات رویداد
                        </h4>
                        <ul class="details-list">
                            ${event.details.map(detail => 
                                `<li><i class="fas fa-check"></i> ${detail}</li>`
                            ).join('')}
                        </ul>
                    </div>
                    
                    <div class="event-status ${statusConfig.class}">
                        ${statusConfig.text}
                    </div>
                </div>
            </div>
        `;
    });
    
    listContainer.innerHTML = eventsHTML;
}

// قالب‌بندی توضیحات رویداد
function formatEventDescription(description) {
    if (!description) return '';
    
    // شکستن پاراگراف‌ها
    const paragraphs = description.split('\n').filter(p => p.trim());
    
    return paragraphs.map(p => `<p>${p}</p>`).join('');
}

// دریافت نام فارسی دسته
function getCategoryName(category) {
    const names = {
        competition: 'مسابقات',
        reading: 'کتابخوانی',
        cultural: 'فرهنگی',
        sports: 'ورزشی',
        educational: 'آموزشی'
    };
    
    return names[category] || category;
}

// به‌روزرسانی آمار
function updateStats() {
    // تعداد مسابقات فعال
    const competitions = allEvents.filter(e => 
        e.category === 'competition' && e.status !== 'completed'
    ).length;
    document.getElementById('totalCompetitions').textContent = competitions;
    
    // تعداد برنامه‌های کتابخوانی
    const reading = allEvents.filter(e => 
        e.category === 'reading' && e.status !== 'completed'
    ).length;
    document.getElementById('totalReading').textContent = reading;
    
    // مجموع شرکت‌کنندگان
    const totalParticipants = allEvents.reduce((sum, event) => 
        sum + (event.participants || 0), 0
    );
    document.getElementById('totalParticipants').textContent = totalParticipants;
    
    // رویدادهای پیش‌رو
    const upcoming = allEvents.filter(e => e.status === 'upcoming').length;
    document.getElementById('upcomingEvents').textContent = upcoming;
}

// نمایش اعلان
function showNotification(text, type = 'info') {
    const oldNotification = document.querySelector('.notification');
    if (oldNotification) oldNotification.remove();
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: ${type === 'success' ? '#27ae60' : 
                    type === 'error' ? '#e74c3c' : 
                    type === 'warning' ? '#f39c12' : '#3498db'};
        color: white;
        padding: 12px 24px;
        border-radius: 8px;
        font-size: 14px;
        z-index: 2000;
        animation: slideDown 0.3s ease-out;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        display: flex;
        align-items: center;
        gap: 10px;
    `;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        info: 'fa-info-circle',
        warning: 'fa-exclamation-triangle'
    };
    
    notification.innerHTML = `
        <i class="fas ${icons[type]}"></i>
        <span>${text}</span>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(-50%) translateY(-10px)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }
    }, 3000);
}

// استایل‌های اضافی
const eventsStyles = `
    <style>
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateX(-50%) translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(-50%) translateY(0);
            }
        }
        
        .event-card {
            animation: fadeInUp 0.5s ease-out;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
`;

document.head.insertAdjacentHTML('beforeend', eventsStyles);