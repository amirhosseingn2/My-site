// ==================== مدیریت سیستم خبری ====================

// داده‌های اولیه
let allNews = [];
let filteredNews = [];
let currentUser = null;

// ==================== بارگذاری اولیه ====================
document.addEventListener('DOMContentLoaded', function() {
    console.log("📰 صفحه اخبار بارگذاری شد");
    
    // بررسی ورود کاربر
    checkUserAccess();
    
    // بارگذاری اخبار
    loadNews();
    
    // تنظیم رویدادها
    setupEventListeners();
    
    // به‌روزرسانی آمار
    updateStats();
});

// بررسی دسترسی کاربر
function checkUserAccess() {
    const userData = localStorage.getItem('currentUser');
    if (!userData) {
        window.location.href = 'index.html';
        return;
    }
    
    currentUser = JSON.parse(userData);
    console.log("👤 کاربر وارد شده:", currentUser.username);
    
    // نمایش نقش کاربر
    const roleBadge = document.getElementById('userRoleBadge');
    if (roleBadge) {
        const roleText = currentUser.role === 'admin' ? 'مدیر' : 
                        currentUser.role === 'secretary' ? 'منشی' : 'کاربر';
        roleBadge.textContent = roleText;
        roleBadge.className = `role-badge ${currentUser.role}`;
    }
}

// بارگذاری اخبار از localStorage
function loadNews() {
    // ایجاد داده‌های اولیه اگر وجود ندارد
    initializeNewsData();
    
    // بارگذاری اخبار
    allNews = JSON.parse(localStorage.getItem('news') || '[]');
    
    // علامت اخبار خوانده نشده برای کاربر فعلی
    markUnreadNews();
    
    // مرتب‌سازی بر اساس تاریخ (جدیدترین اول)
    allNews.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    console.log(`📊 ${allNews.length} خبر بارگذاری شد`);
    
    // نمایش اخبار
    displayNews(allNews);
    
    // به‌روزرسانی آمار
    updateStats();
    
    // به‌روزرسانی زمان آخرین به‌روزرسانی
    updateLastUpdateTime();
}

// ایجاد داده‌های اولیه خبری
function initializeNewsData() {
    let news = JSON.parse(localStorage.getItem('news') || '[]');
    
    if (news.length === 0) {
        const sampleNews = [
            {
                id: 1,
                title: "📢 اطلاعیه مهم: شروع دوره جدید",
                content: "با سلام و احترام، به اطلاع کلیه اعضای گروهان شهید توکلی می‌رساند دوره جدید آموزش‌های تخصصی از تاریخ ۱۴۰۳/۰۱/۲۰ آغاز می‌شود.",
                type: "announcement",
                priority: "important",
                sender: {
                    name: "مدیریت گروهان",
                    role: "admin",
                    avatar: "M"
                },
                attachments: [
                    {
                        name: "برنامه دوره.pdf",
                        type: "pdf",
                        size: "2.4 MB",
                        url: "#"
                    }
                ],
                createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 روز پیش
                expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
                readBy: []
            },
            {
                id: 2,
                title: "🏆 مسابقات کتابخوانی",
                content: "مسابقات کتابخوانی گروهان در موضوع دفاع مقدس برگزار می‌شود. علاقه‌مندان می‌توانند تا پایان هفته ثبت نام کنند.",
                type: "news",
                priority: "normal",
                sender: {
                    name: "کمیته فرهنگی",
                    role: "secretary",
                    avatar: "ف"
                },
                images: [
                    "https://via.placeholder.com/800x400/3498db/ffffff?text=مسابقات+کتابخوانی",
                    "https://via.placeholder.com/800x400/2ecc71/ffffff?text=دفاع+مقدس"
                ],
                createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // 1 روز پیش
                readBy: []
            },
            {
                id: 3,
                title: "📋 لیست نفرات برتر هفته",
                content: "اسامی نفرات برتر هفته گذشته در رشته‌های مختلف اعلام شد. از این عزیزان تقدیر به عمل خواهد آمد.",
                type: "announcement",
                priority: "normal",
                sender: {
                    name: "منشی گروهان",
                    role: "secretary",
                    avatar: "م"
                },
                attachments: [
                    {
                        name: "لیست برترها.xlsx",
                        type: "excel",
                        size: "1.8 MB",
                        url: "#"
                    },
                    {
                        name: "تصویر تقدیر.jpg",
                        type: "image",
                        size: "850 KB",
                        url: "#"
                    }
                ],
                createdAt: new Date().toISOString(), // امروز
                readBy: []
            }
        ];
        
        localStorage.setItem('news', JSON.stringify(sampleNews));
        console.log("✅ داده‌های نمونه خبری ایجاد شدند");
    }
}

// علامت‌گذاری اخبار خوانده نشده برای کاربر فعلی
function markUnreadNews() {
    const username = currentUser?.username;
    if (!username) return;
    
    allNews.forEach(news => {
        if (!news.readBy) {
            news.readBy = [];
        }
    });
    
    localStorage.setItem('news', JSON.stringify(allNews));
}

// نمایش اخبار
function displayNews(newsArray) {
    const container = document.getElementById('newsContainer');
    if (!container) return;
    
    if (newsArray.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-newspaper"></i>
                <h3>خبری برای نمایش وجود ندارد</h3>
                <p>هنوز هیچ خبر یا اطلاعیه‌ای منتشر نشده است.</p>
            </div>
        `;
        return;
    }
    
    let newsHTML = '';
    
    newsArray.forEach((news, index) => {
        const isRead = news.readBy?.includes(currentUser?.username) || false;
        const isImportant = news.priority === 'important';
        const newsDate = new Date(news.createdAt);
        const timeAgo = getTimeAgo(newsDate);
        
        // نوع خبر
        const typeConfig = getNewsTypeConfig(news.type);
        
        // تصویر اصلی (اگر وجود دارد)
        const mainImage = news.images && news.images.length > 0 ? 
            `<img src="${news.images[0]}" alt="${news.title}" data-lightbox="news-${news.id}" data-title="${news.title}">` : '';
        
        // لیست فایل‌ها
        let filesHTML = '';
        if (news.attachments && news.attachments.length > 0) {
            filesHTML = `
                <div class="attachments">
                    <h4><i class="fas fa-paperclip"></i> فایل‌های ضمیمه (${news.attachments.length})</h4>
                    <div class="file-list">
            `;
            
            news.attachments.forEach((file, fileIndex) => {
                const fileIcon = getFileIcon(file.type);
                filesHTML += `
                    <a href="${file.url}" class="file-item" download="${file.name}" onclick="downloadFile(event, '${file.name}')">
                        <i class="fas ${fileIcon} file-icon"></i>
                        <span class="file-name">${file.name}</span>
                        <span class="file-size">${file.size}</span>
                        <span class="download-btn">
                            <i class="fas fa-download"></i>
                        </span>
                    </a>
                `;
            });
            
            filesHTML += '</div></div>';
        }
        
        // لیست تصاویر
        let imagesHTML = '';
        if (news.images && news.images.length > 0) {
            imagesHTML = '<div style="margin-top: 15px;">';
            news.images.forEach((image, imgIndex) => {
                if (imgIndex > 0) { // اولین تصویر قبلاً نمایش داده شده
                    imagesHTML += `
                        <img src="${image}" alt="تصویر ${imgIndex + 1}" 
                             style="max-width: 150px; margin: 5px; cursor: pointer;"
                             data-lightbox="news-${news.id}" data-title="${news.title}">
                    `;
                }
            });
            imagesHTML += '</div>';
        }
        
        newsHTML += `
            <div class="news-card ${isImportant ? 'important' : ''}" data-id="${news.id}" data-type="${news.type}" data-priority="${news.priority}">
                <div class="news-card-header">
                    <div class="news-type">
                        <span class="type-badge ${typeConfig.badgeClass}">
                            <i class="${typeConfig.icon}"></i>
                            ${typeConfig.label}
                        </span>
                        ${isImportant ? '<span class="type-badge badge-important"><i class="fas fa-exclamation-circle"></i> مهم</span>' : ''}
                    </div>
                    <div class="news-date">
                        <i class="far fa-clock"></i>
                        ${timeAgo}
                    </div>
                </div>
                
                <div class="news-card-body">
                    <h3 class="news-title">${news.title}</h3>
                    <div class="news-content">
                        ${mainImage}
                        <p>${news.content}</p>
                        ${imagesHTML}
                        ${filesHTML}
                    </div>
                </div>
                
                <div class="news-card-footer">
                    <div class="sender-info">
                        <div class="sender-avatar">${news.sender.avatar}</div>
                        <div class="sender-details">
                            <h5>${news.sender.name}</h5>
                            <small>${getRoleText(news.sender.role)}</small>
                        </div>
                    </div>
                    <div class="read-status">
                        <span class="read-badge ${isRead ? 'read' : 'unread'}">
                            ${isRead ? '<i class="fas fa-check-circle"></i> خوانده شده' : '<i class="fas fa-envelope"></i> خوانده نشده'}
                        </span>
                        <button class="btn-small" onclick="viewNewsDetail(${news.id})">
                            <i class="fas fa-expand-alt"></i> مشاهده کامل
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = newsHTML;
    
    // اعمال انیمیشن با تاخیر
    setTimeout(() => {
        const cards = container.querySelectorAll('.news-card');
        cards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.1}s`;
        });
    }, 100);
}

// دریافت پیکربندی نوع خبر
function getNewsTypeConfig(type) {
    const configs = {
        announcement: {
            label: 'اطلاعیه',
            icon: 'fas fa-bullhorn',
            badgeClass: 'badge-announcement',
            color: '#17a2b8'
        },
        news: {
            label: 'خبر',
            icon: 'fas fa-newspaper',
            badgeClass: 'badge-news',
            color: '#28a745'
        },
        file: {
            label: 'فایل',
            icon: 'fas fa-file',
            badgeClass: 'badge-file',
            color: '#6c757d'
        },
        important: {
            label: 'مهم',
            icon: 'fas fa-exclamation-circle',
            badgeClass: 'badge-important',
            color: '#dc3545'
        }
    };
    
    return configs[type] || configs.news;
}

// دریافت آیکون فایل بر اساس نوع
function getFileIcon(fileType) {
    const icons = {
        pdf: 'fa-file-pdf',
        doc: 'fa-file-word',
        docx: 'fa-file-word',
        xls: 'fa-file-excel',
        xlsx: 'fa-file-excel',
        ppt: 'fa-file-powerpoint',
        pptx: 'fa-file-powerpoint',
        image: 'fa-file-image',
        jpg: 'fa-file-image',
        jpeg: 'fa-file-image',
        png: 'fa-file-image',
        zip: 'fa-file-archive',
        rar: 'fa-file-archive',
        mp4: 'fa-file-video',
        mp3: 'fa-file-audio',
        txt: 'fa-file-alt'
    };
    
    const extension = fileType.toLowerCase();
    return icons[extension] || 'fa-file';
}

// دریافت متن نقش
function getRoleText(role) {
    const roles = {
        admin: 'مدیر سیستم',
        secretary: 'منشی گروهان',
        user: 'عضو گروهان'
    };
    
    return roles[role] || role;
}

// دریافت زمان گذشته
function getTimeAgo(date) {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'همین الان';
    if (diffMins < 60) return `${diffMins} دقیقه پیش`;
    if (diffHours < 24) return `${diffHours} ساعت پیش`;
    if (diffDays < 7) return `${diffDays} روز پیش`;
    
    return date.toLocaleDateString('fa-IR');
}

// تنظیم رویدادها
function setupEventListeners() {
    // جستجو
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            filterNews();
        });
    }
    
    // فیلتر دکمه‌ها
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // حذف کلاس active از همه
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // اضافه کردن به دکمه کلیک شده
            this.classList.add('active');
            // اعمال فیلتر
            filterNews();
        });
    });
    
    // مرتب‌سازی
    const sortSelect = document.getElementById('sortSelect');
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            filterNews();
        });
    }
    
    // دکمه به‌روزرسانی
    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            loadNews();
            showMessage('اخبار به‌روزرسانی شد', 'success');
        });
    }
    
    // کلیک روی آمار
    const statCards = document.querySelectorAll('.stat-card');
    statCards.forEach(card => {
        card.addEventListener('click', function() {
            const type = this.getAttribute('data-type');
            if (type === 'all') {
                // حذف فیلتر
                filterButtons.forEach(btn => btn.classList.remove('active'));
                filterButtons[0].classList.add('active');
            } else {
                // فعال کردن فیلتر مربوطه
                filterButtons.forEach(btn => {
                    if (btn.getAttribute('data-filter') === type) {
                        btn.click();
                    }
                });
            }
        });
    });
    
    // مودال
    const modal = document.getElementById('newsModal');
    const closeModalBtns = document.querySelectorAll('.close-modal, .close-modal-btn');
    
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            modal.style.display = 'none';
        });
    });
    
    // بستن مودال با کلیک خارج
    window.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
    
    // دانلود همه فایل‌ها
    const downloadAllBtn = document.getElementById('downloadAllBtn');
    if (downloadAllBtn) {
        downloadAllBtn.addEventListener('click', function() {
            const newsId = this.getAttribute('data-news-id');
            downloadAllFiles(newsId);
        });
    }
}

// فیلتر اخبار
function filterNews() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const activeFilter = document.querySelector('.filter-btn.active').getAttribute('data-filter');
    const sortBy = document.getElementById('sortSelect').value;
    
    // فیلتر بر اساس جستجو
    let results = allNews.filter(news => {
        const matchesSearch = !searchTerm || 
            news.title.toLowerCase().includes(searchTerm) ||
            news.content.toLowerCase().includes(searchTerm) ||
            news.sender.name.toLowerCase().includes(searchTerm);
        
        const matchesFilter = activeFilter === 'all' || 
            news.type === activeFilter ||
            (activeFilter === 'important' && news.priority === 'important');
        
        return matchesSearch && matchesFilter;
    });
    
    // مرتب‌سازی
    results.sort((a, b) => {
        switch(sortBy) {
            case 'newest':
                return new Date(b.createdAt) - new Date(a.createdAt);
            case 'oldest':
                return new Date(a.createdAt) - new Date(b.createdAt);
            case 'important':
                if (a.priority === 'important' && b.priority !== 'important') return -1;
                if (a.priority !== 'important' && b.priority === 'important') return 1;
                return new Date(b.createdAt) - new Date(a.createdAt);
            default:
                return new Date(b.createdAt) - new Date(a.createdAt);
        }
    });
    
    filteredNews = results;
    displayNews(results);
}

// به‌روزرسانی آمار
function updateStats() {
    // کل اخبار
    document.getElementById('totalNews').textContent = allNews.length;
    
    // اخبار مهم
    const importantCount = allNews.filter(news => news.priority === 'important').length;
    document.getElementById('importantNews').textContent = importantCount;
    
    // تعداد فایل‌ها
    let fileCount = 0;
    allNews.forEach(news => {
        if (news.attachments) {
            fileCount += news.attachments.length;
        }
    });
    document.getElementById('fileCount').textContent = fileCount;
    
    // اخبار خوانده نشده
    const unreadCount = allNews.filter(news => 
        !news.readBy?.includes(currentUser?.username)
    ).length;
    document.getElementById('unreadCount').textContent = unreadCount;
}

// به‌روزرسانی زمان آخرین به‌روزرسانی
function updateLastUpdateTime() {
    const now = new Date();
    const timeString = now.toLocaleTimeString('fa-IR', {
        hour: '2-digit',
        minute: '2-digit'
    });
    const dateString = now.toLocaleDateString('fa-IR');
    
    document.getElementById('lastUpdate').textContent = `${dateString} - ${timeString}`;
}

// مشاهده جزئیات خبر
function viewNewsDetail(newsId) {
    const news = allNews.find(n => n.id === newsId);
    if (!news) return;
    
    // علامت به عنوان خوانده شده
    if (currentUser?.username && !news.readBy?.includes(currentUser.username)) {
        news.readBy.push(currentUser.username);
        localStorage.setItem('news', JSON.stringify(allNews));
        updateStats();
    }
    
    const modal = document.getElementById('newsModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalBody = document.getElementById('modalBody');
    const downloadAllBtn = document.getElementById('downloadAllBtn');
    
    // تنظیم عنوان
    modalTitle.textContent = news.title;
    
    // ساخت محتوا
    let contentHTML = `
        <div style="margin-bottom: 20px;">
            <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                <div class="type-badge ${getNewsTypeConfig(news.type).badgeClass}">
                    <i class="${getNewsTypeConfig(news.type).icon}"></i>
                    ${getNewsTypeConfig(news.type).label}
                </div>
                ${news.priority === 'important' ? 
                    '<span class="type-badge badge-important"><i class="fas fa-exclamation-circle"></i> مهم</span>' : ''}
                <span style="color: #6c757d; font-size: 0.9rem;">
                    <i class="far fa-clock"></i>
                    ${new Date(news.createdAt).toLocaleDateString('fa-IR')}
                </span>
            </div>
            
            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div class="sender-avatar" style="width: 50px; height: 50px;">${news.sender.avatar}</div>
                    <div>
                        <h4 style="margin: 0; color: #2c3e50;">${news.sender.name}</h4>
                        <small style="color: #6c757d;">${getRoleText(news.sender.role)}</small>
                    </div>
                </div>
            </div>
        </div>
        
        <div style="line-height: 1.8; margin-bottom: 25px; font-size: 1.05rem;">
            ${news.content}
        </div>
    `;
    
    // نمایش تصاویر
    if (news.images && news.images.length > 0) {
        contentHTML += `
            <h4><i class="fas fa-images"></i> گالری تصاویر</h4>
            <div style="display: flex; flex-wrap: wrap; gap: 10px; margin: 15px 0 25px 0;">
        `;
        
        news.images.forEach((image, index) => {
            contentHTML += `
                <a href="${image}" data-lightbox="modal-${news.id}" data-title="${news.title} - تصویر ${index + 1}">
                    <img src="${image}" alt="تصویر ${index + 1}" 
                         style="width: 150px; height: 100px; object-fit: cover; border-radius: 6px; cursor: pointer;">
                </a>
            `;
        });
        
        contentHTML += '</div>';
    }
    
    // نمایش فایل‌ها
    if (news.attachments && news.attachments.length > 0) {
        contentHTML += `
            <h4><i class="fas fa-paperclip"></i> فایل‌های ضمیمه (${news.attachments.length})</h4>
            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 15px 0;">
                <div style="display: flex; flex-direction: column; gap: 10px;">
        `;
        
        news.attachments.forEach(file => {
            const fileIcon = getFileIcon(file.type);
            contentHTML += `
                <div style="display: flex; align-items: center; gap: 15px; padding: 10px; background: white; border-radius: 6px;">
                    <i class="fas ${fileIcon}" style="font-size: 24px; color: #6c757d;"></i>
                    <div style="flex: 1;">
                        <div style="font-weight: 500; color: #2c3e50;">${file.name}</div>
                        <div style="font-size: 0.85rem; color: #6c757d;">${file.size}</div>
                    </div>
                    <a href="${file.url}" class="download-btn" download="${file.name}" onclick="downloadFile(event, '${file.name}')">
                        <i class="fas fa-download"></i> دانلود
                    </a>
                </div>
            `;
        });
        
        contentHTML += '</div></div>';
        
        // نمایش دکمه دانلود همه
        downloadAllBtn.style.display = 'block';
        downloadAllBtn.setAttribute('data-news-id', news.id);
    } else {
        downloadAllBtn.style.display = 'none';
    }
    
    // تاریخ انقضا (اگر وجود دارد)
    if (news.expiresAt) {
        const expiresDate = new Date(news.expiresAt);
        const now = new Date();
        const daysLeft = Math.ceil((expiresDate - now) / (1000 * 60 * 60 * 24));
        
        if (daysLeft > 0) {
            contentHTML += `
                <div style="background: #fff3cd; padding: 10px 15px; border-radius: 6px; border-right: 4px solid #ffc107; margin-top: 20px;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <i class="fas fa-clock" style="color: #856404;"></i>
                        <span style="color: #856404;">
                            این اطلاعیه تا ${daysLeft} روز دیگر معتبر است
                            (تا ${expiresDate.toLocaleDateString('fa-IR')})
                        </span>
                    </div>
                </div>
            `;
        }
    }
    
    modalBody.innerHTML = contentHTML;
    modal.style.display = 'flex';
    
    // راه‌اندازی مجدد لایت‌باکس
    if (typeof lightbox !== 'undefined') {
        lightbox.option({
            'albumLabel': 'تصویر %1 از %2'
        });
    }
}

// دانلود فایل
function downloadFile(event, fileName) {
    event.preventDefault();
    
    // در واقعیت اینجا درخواست دانلود به سرور ارسال می‌شود
    // برای نمونه، یک پیام نمایش می‌دهیم
    
    showMessage(`فایل "${fileName}" در حال دانلود است...`, 'info');
    
    // شبیه‌سازی دانلود
    setTimeout(() => {
        showMessage(`فایل "${fileName}" با موفقیت دانلود شد`, 'success');
        
        // ثبت در تاریخچه دانلودها
        addDownloadLog(fileName);
    }, 1500);
}

// دانلود همه فایل‌های یک خبر
function downloadAllFiles(newsId) {
    const news = allNews.find(n => n.id === parseInt(newsId));
    if (!news || !news.attachments || news.attachments.length === 0) return;
    
    showMessage(`در حال دانلود ${news.attachments.length} فایل...`, 'info');
    
    // شبیه‌سازی دانلود همه فایل‌ها
    setTimeout(() => {
        showMessage(`همه فایل‌ها با موفقیت دانلود شدند`, 'success');
        
        // ثبت در تاریخچه
        news.attachments.forEach(file => {
            addDownloadLog(file.name);
        });
    }, 2000);
}

// ثبت تاریخچه دانلود
function addDownloadLog(fileName) {
    const downloads = JSON.parse(localStorage.getItem('downloadLogs') || '[]');
    
    downloads.push({
        username: currentUser?.username,
        fileName: fileName,
        downloadedAt: new Date().toISOString(),
        ip: 'local'
    });
    
    // نگهداری فقط ۱۰۰ لاگ آخر
    if (downloads.length > 100) {
        downloads.shift();
    }
    
    localStorage.setItem('downloadLogs', JSON.stringify(downloads));
}

// نمایش پیام
function showMessage(text, type = 'info') {
    const container = document.getElementById('messageContainer');
    if (!container) return;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.style.cssText = `
        padding: 12px 15px;
        margin: 10px 0;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 10px;
        animation: slideIn 0.3s ease-out;
    `;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        info: 'fa-info-circle',
        warning: 'fa-exclamation-triangle'
    };
    
    const colors = {
        success: '#d4edda',
        error: '#f8d7da',
        info: '#d1ecf1',
        warning: '#fff3cd'
    };
    
    const textColors = {
        success: '#155724',
        error: '#721c24',
        info: '#0c5460',
        warning: '#856404'
    };
    
    messageDiv.innerHTML = `
        <i class="fas ${icons[type]}" style="color: ${textColors[type]};"></i>
        <span style="color: ${textColors[type]};">${text}</span>
    `;
    
    messageDiv.style.background = colors[type];
    messageDiv.style.border = `1px solid ${type === 'success' ? '#c3e6cb' : type === 'error' ? '#f5c6cb' : type === 'info' ? '#bee5eb' : '#ffeaa7'}`;
    
    // حذف پیام قبلی
    const oldMessage = container.querySelector('.message');
    if (oldMessage) {
        oldMessage.remove();
    }
    
    container.appendChild(messageDiv);
    
    // حذف خودکار
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.style.opacity = '0';
            messageDiv.style.transform = 'translateY(-10px)';
            setTimeout(() => {
                if (messageDiv.parentNode) {
                    messageDiv.remove();
                }
            }, 300);
        }
    }, 5000);
}

// ==================== استایل‌های انیمیشن ====================
const animationStyles = `
    <style>
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
`;

document.head.insertAdjacentHTML('beforeend', animationStyles);