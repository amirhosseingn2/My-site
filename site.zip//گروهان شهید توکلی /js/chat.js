// ==================== سیستم چت ساده شبیه تلگرام ====================

// داده‌های اولیه
let currentUser = null;
let allMessages = [];
let selectedFiles = [];
let isTyping = false;

// ==================== بارگذاری اولیه ====================
document.addEventListener('DOMContentLoaded', function() {
    console.log("💬 چت تلگرامی بارگذاری شد");
    
    // بررسی ورود کاربر
    checkUserAccess();
    
    // بارگذاری داده‌ها
    loadChatData();
    
    // تنظیم رویدادها
    setupEventListeners();
    
    // تنظیم ارتفاع خودکار textarea
    setupTextareaAutoResize();
    
    // اسکرول به پایین
    scrollToBottom();
});

// بررسی دسترسی کاربر
function checkUserAccess() {
    const userData = localStorage.getItem('currentUser');
    if (!userData) {
        window.location.href = 'index.html';
        return;
    }
    
    currentUser = JSON.parse(userData);
    console.log("👤 کاربر:", currentUser.username);
}

// بارگذاری داده‌های چت
function loadChatData() {
    // بارگذاری پیام‌ها
    allMessages = JSON.parse(localStorage.getItem('chatMessages') || '[]');
    
    // اگر پیامی نیست، نمونه ایجاد کن
    if (allMessages.length === 0) {
        createSampleMessages();
    }
    
    console.log(`📨 ${allMessages.length} پیام بارگذاری شد`);
    
    // نمایش پیام‌ها
    displayMessages();
}

// ایجاد پیام‌های نمونه
function createSampleMessages() {
    const sampleMessages = [
        {
            id: 1,
            sender: {
                username: "system",
                name: "سیستم",
                avatar: "⚙️"
            },
            text: "به چت گروهان شهید توکلی خوش آمدید 👋",
            time: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
            type: "system"
        },
        {
            id: 2,
            sender: {
                username: "403825663",
                name: "مدیر سیستم",
                avatar: "م"
            },
            text: "سلام به همه اعضای گروهان! امروز جلسه ساعت ۱۸ در سالن اصلی برگزار می‌شود.",
            time: new Date(Date.now() - 1.5 * 60 * 60 * 1000).toISOString(),
            type: "text"
        },
        {
            id: 3,
            sender: {
                username: "user1",
                name: "سرباز نمونه",
                avatar: "س"
            },
            text: "سلام 👋 برنامه امروز رو میشه دقیق‌تر بگید؟",
            time: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
            type: "text",
            read: true
        },
        {
            id: 4,
            sender: {
                username: "secretary",
                name: "منشی گروهان",
                avatar: "م"
            },
            text: "جلسه امروز در مورد برنامه‌های هفته آینده و مسابقات کتابخوانی است.",
            time: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
            type: "text"
        },
        {
            id: 5,
            sender: {
                username: "user2",
                name: "رامین محمدی",
                avatar: "ر"
            },
            text: "ممنون از اطلاع‌رسانی 👍",
            time: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
            type: "text",
            read: true
        }
    ];
    
    allMessages = sampleMessages;
    localStorage.setItem('chatMessages', JSON.stringify(sampleMessages));
    console.log("✅ پیام‌های نمونه ایجاد شدند");
}

// نمایش پیام‌ها
function displayMessages() {
    const container = document.getElementById('messagesContainer');
    const emptyState = document.getElementById('emptyState');
    
    if (!container) return;
    
    // اگر پیامی نیست، حالت خالی را نشان بده
    if (allMessages.length === 0) {
        if (emptyState) emptyState.style.display = 'block';
        return;
    }
    
    // مخفی کردن حالت خالی
    if (emptyState) emptyState.style.display = 'none';
    
    let messagesHTML = '';
    let lastDate = null;
    
    // گروه‌بندی پیام‌ها بر اساس تاریخ
    allMessages.forEach(message => {
        const messageDate = new Date(message.time);
        const dateStr = messageDate.toLocaleDateString('fa-IR');
        const isMyMessage = message.sender.username === currentUser.username;
        const isSystem = message.type === 'system';
        
        // اگر تاریخ تغییر کرده، جداکننده اضافه کن
        if (lastDate !== dateStr) {
            messagesHTML += `
                <div class="date-divider">
                    <span>${dateStr}</span>
                </div>
            `;
            lastDate = dateStr;
        }
        
        // پیام سیستمی
        if (isSystem) {
            messagesHTML += `
                <div class="system-message">
                    <div class="message-bubble">
                        ${message.text}
                    </div>
                </div>
            `;
            return;
        }
        
        // پیام عادی
        messagesHTML += `
            <div class="message ${isMyMessage ? 'my-message' : 'other-message'}">
                ${!isMyMessage ? `
                    <div class="message-avatar">
                        ${message.sender.avatar}
                    </div>
                ` : ''}
                
                <div class="message-content">
                    ${!isMyMessage ? `
                        <div class="message-sender">${message.sender.name}</div>
                    ` : ''}
                    
                    <div class="message-bubble">
                        <div class="message-text">${formatMessageText(message.text)}</div>
                        <div class="message-time">
                            ${formatTime(message.time)}
                            ${isMyMessage ? '<i class="fas fa-check' + (message.read ? '-double' : '') + '"></i>' : ''}
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = messagesHTML;
    
    // اسکرول به آخرین پیام
    setTimeout(scrollToBottom, 100);
}

// قالب‌بندی متن پیام
function formatMessageText(text) {
    if (!text) return '';
    
    // تبدیل لینک‌ها
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    let formatted = text.replace(urlRegex, url => 
        `<a href="${url}" target="_blank" style="color: #58a6ff; text-decoration: none;">${url}</a>`
    );
    
    // حفظ خطوط
    formatted = formatted.replace(/\n/g, '<br>');
    
    return formatted;
}

// قالب‌بندی زمان
function formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    const diffMinutes = Math.floor(diff / (1000 * 60));
    
    if (diffMinutes < 1) return 'همین الان';
    if (diffMinutes < 60) return `${diffMinutes} دقیقه قبل`;
    
    return date.toLocaleTimeString('fa-IR', {
        hour: '2-digit',
        minute: '2-digit'
    });
}

// تنظیم رویدادها
function setupEventListeners() {
    // دکمه ارسال
    const sendBtn = document.getElementById('sendBtn');
    const messageInput = document.getElementById('messageInput');
    
    if (sendBtn) {
        sendBtn.addEventListener('click', sendMessage);
    }
    
    if (messageInput) {
        // ارسال با Enter (بدون Shift)
        messageInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
        
        // تایپ کردن
        messageInput.addEventListener('input', function() {
            updateSendButton();
            simulateTyping();
        });
    }
    
    // دکمه ضمیمه
    const attachmentBtn = document.getElementById('attachmentBtn');
    if (attachmentBtn) {
        attachmentBtn.addEventListener('click', function() {
            showAttachmentMenu();
        });
    }
    
    // دکمه ایموجی
    const emojiBtn = document.getElementById('emojiBtn');
    if (emojiBtn) {
        emojiBtn.addEventListener('click', function() {
            insertEmoji('😊');
        });
    }
}

// تنظیم ارتفاع خودکار textarea
function setupTextareaAutoResize() {
    const textarea = document.getElementById('messageInput');
    if (!textarea) return;
    
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });
}

// به‌روزرسانی وضعیت دکمه ارسال
function updateSendButton() {
    const sendBtn = document.getElementById('sendBtn');
    const messageInput = document.getElementById('messageInput');
    
    if (!sendBtn || !messageInput) return;
    
    const hasText = messageInput.value.trim().length > 0;
    const hasFiles = selectedFiles.length > 0;
    
    sendBtn.disabled = !(hasText || hasFiles);
}

// شبیه‌سازی تایپ کردن
function simulateTyping() {
    const messageInput = document.getElementById('messageInput');
    if (!messageInput || messageInput.value.trim().length === 0) {
        clearTypingIndicator();
        return;
    }
    
    if (!isTyping) {
        isTyping = true;
        showTypingIndicator();
        
        // توقف تایپ بعد از 3 ثانیه
        setTimeout(() => {
            if (isTyping) {
                isTyping = false;
                clearTypingIndicator();
            }
        }, 3000);
    }
}

// نمایش نشانگر تایپ
function showTypingIndicator() {
    const container = document.getElementById('messagesContainer');
    if (!container) return;
    
    // حذف نشانگر قبلی
    const existingIndicator = container.querySelector('.typing-indicator');
    if (existingIndicator) existingIndicator.remove();
    
    // ایجاد نشانگر جدید
    const indicator = document.createElement('div');
    indicator.className = 'typing-indicator';
    indicator.innerHTML = `
        <div class="typing-text">در حال نوشتن...</div>
        <div class="typing-dots">
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;
    
    container.appendChild(indicator);
    scrollToBottom();
}

// پاک کردن نشانگر تایپ
function clearTypingIndicator() {
    const container = document.getElementById('messagesContainer');
    if (!container) return;
    
    const indicator = container.querySelector('.typing-indicator');
    if (indicator) indicator.remove();
}

// ارسال پیام
function sendMessage() {
    const messageInput = document.getElementById('messageInput');
    const messageText = messageInput ? messageInput.value.trim() : '';
    
    if (!messageText && selectedFiles.length === 0) {
        showNotification('لطفاً پیامی بنویسید', 'warning');
        return;
    }
    
    // ایجاد پیام جدید
    const newMessage = {
        id: Date.now(),
        sender: {
            username: currentUser.username,
            name: currentUser.fullName,
            avatar: currentUser.fullName.charAt(0)
        },
        text: messageText,
        time: new Date().toISOString(),
        type: selectedFiles.length > 0 ? 'file' : 'text',
        read: false
    };
    
    // اضافه کردن به لیست
    allMessages.push(newMessage);
    
    // ذخیره در localStorage
    localStorage.setItem('chatMessages', JSON.stringify(allMessages));
    
    // نمایش پیام جدید
    displayMessages();
    
    // پاک کردن ورودی
    if (messageInput) {
        messageInput.value = '';
        messageInput.style.height = 'auto';
        messageInput.focus();
    }
    
    // پاک کردن فایل‌ها
    selectedFiles = [];
    
    // به‌روزرسانی دکمه ارسال
    updateSendButton();
    
    // توقف تایپ
    isTyping = false;
    clearTypingIndicator();
    
    // نمایش اعلان
    showNotification('پیام ارسال شد', 'success');
}

// نمایش منوی ضمیمه
function showAttachmentMenu() {
    // ایجاد یک مینی مودال
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        bottom: 80px;
        left: 20px;
        right: 20px;
        background: #1a1f26;
        border-radius: 12px;
        padding: 15px;
        border: 1px solid #2d3743;
        box-shadow: 0 8px 32px rgba(0,0,0,0.4);
        z-index: 2000;
        animation: slideUp 0.3s ease-out;
    `;
    
    modal.innerHTML = `
        <div style="display: flex; flex-direction: column; gap: 10px;">
            <button class="attachment-option" data-type="photo">
                <i class="fas fa-camera" style="color: #58a6ff;"></i>
                <span>عکس</span>
            </button>
            <button class="attachment-option" data-type="document">
                <i class="fas fa-file" style="color: #3fb950;"></i>
                <span>سند</span>
            </button>
            <button class="attachment-option" data-type="location">
                <i class="fas fa-map-marker-alt" style="color: #e34c26;"></i>
                <span>موقعیت</span>
            </button>
            <button class="attachment-option" data-type="contact">
                <i class="fas fa-user" style="color: #f1e05a;"></i>
                <span>مخاطب</span>
            </button>
        </div>
        <button id="closeAttachmentMenu" style="position: absolute; top: 10px; left: 10px; background: none; border: none; color: #8b949e; font-size: 18px; cursor: pointer;">
            ×
        </button>
        
        <style>
            .attachment-option {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 12px;
                background: none;
                border: none;
                color: #e6edf3;
                font-size: 14px;
                cursor: pointer;
                border-radius: 8px;
                transition: background 0.2s;
                text-align: right;
                width: 100%;
            }
            
            .attachment-option:hover {
                background: #2d3743;
            }
            
            .attachment-option i {
                font-size: 20px;
            }
        </style>
    `;
    
    document.body.appendChild(modal);
    
    // بستن با کلیک روی دکمه
    document.getElementById('closeAttachmentMenu').addEventListener('click', function() {
        modal.remove();
    });
    
    // بستن با کلیک خارج
    setTimeout(() => {
        const closeOnClickOutside = (e) => {
            if (!modal.contains(e.target) && e.target.id !== 'attachmentBtn') {
                modal.remove();
                document.removeEventListener('click', closeOnClickOutside);
            }
        };
        document.addEventListener('click', closeOnClickOutside);
    }, 100);
    
    // رویدادهای گزینه‌ها
    modal.querySelectorAll('.attachment-option').forEach(option => {
        option.addEventListener('click', function() {
            const type = this.getAttribute('data-type');
            handleAttachment(type);
            modal.remove();
        });
    });
}

// مدیریت ضمیمه
function handleAttachment(type) {
    switch(type) {
        case 'photo':
            selectPhoto();
            break;
        case 'document':
            selectDocument();
            break;
        case 'location':
            showLocation();
            break;
        case 'contact':
            selectContact();
            break;
    }
}

// انتخاب عکس
function selectPhoto() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.multiple = true;
    
    input.onchange = function(e) {
        const files = e.target.files;
        if (files.length > 0) {
            // شبیه‌سازی آپلود
            showNotification(`${files.length} عکس انتخاب شد`, 'info');
            
            // نمایش پیش‌نمایش
            showFilePreview(files[0]);
        }
    };
    
    input.click();
}

// انتخاب سند
function selectDocument() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.pdf,.doc,.docx,.txt,.xlsx';
    
    input.onchange = function(e) {
        const file = e.target.files[0];
        if (file) {
            showNotification(`فایل ${file.name} انتخاب شد`, 'info');
            showFilePreview(file);
        }
    };
    
    input.click();
}

// نمایش موقعیت
function showLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            
            // ارسال موقعیت به عنوان پیام
            const locationMessage = `موقعیت من: https://maps.google.com/?q=${lat},${lng}`;
            document.getElementById('messageInput').value = locationMessage;
            updateSendButton();
            
            showNotification('موقعیت دریافت شد', 'success');
        }, function() {
            showNotification('دسترسی به موقعیت مجاز نیست', 'error');
        });
    } else {
        showNotification('مرورگر شما از موقعیت‌یابی پشتیبانی نمی‌کند', 'error');
    }
}

// انتخاب مخاطب
function selectContact() {
    // در حالت واقعی از Contacts API استفاده می‌شود
    // برای نمونه یک مخاطب فرضی
    const contact = {
        name: 'مخاطب نمونه',
        phone: '09123456789'
    };
    
    const contactMessage = `مخاطب: ${contact.name}\nشماره: ${contact.phone}`;
    document.getElementById('messageInput').value = contactMessage;
    updateSendButton();
    
    showNotification('مخاطب انتخاب شد', 'success');
}

// نمایش پیش‌نمایش فایل
function showFilePreview(file) {
    const container = document.querySelector('.message-input-container');
    if (!container) return;
    
    // حذف پیش‌نمایش قبلی
    const existingPreview = document.querySelector('.file-preview');
    if (existingPreview) existingPreview.remove();
    
    // ایجاد پیش‌نمایش جدید
    const preview = document.createElement('div');
    preview.className = 'file-preview';
    
    const fileIcon = file.type.startsWith('image/') ? 'fa-image' : 'fa-file';
    
    preview.innerHTML = `
        <i class="fas ${fileIcon} file-icon"></i>
        <div class="file-info">
            <div class="file-name">${file.name}</div>
            <div class="file-size">${formatFileSize(file.size)}</div>
        </div>
        <button class="remove-file" onclick="this.parentElement.remove()">
            ×
        </button>
    `;
    
    // اضافه کردن پیش‌نمایش بالای باکس ورودی
    container.parentNode.insertBefore(preview, container);
    
    // ذخیره فایل
    selectedFiles = [file];
    updateSendButton();
}

// فرمت‌بندی حجم فایل
function formatFileSize(bytes) {
    if (bytes === 0) return '0 بایت';
    
    const k = 1024;
    const sizes = ['بایت', 'کیلوبایت', 'مگابایت'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

// درج ایموجی
function insertEmoji(emoji) {
    const messageInput = document.getElementById('messageInput');
    if (!messageInput) return;
    
    const cursorPos = messageInput.selectionStart;
    const text = messageInput.value;
    
    messageInput.value = text.substring(0, cursorPos) + emoji + text.substring(cursorPos);
    messageInput.focus();
    messageInput.selectionStart = messageInput.selectionEnd = cursorPos + emoji.length;
    
    // به‌روزرسانی ارتفاع
    messageInput.style.height = 'auto';
    messageInput.style.height = Math.min(messageInput.scrollHeight, 120) + 'px';
    
    updateSendButton();
}

// اسکرول به پایین
function scrollToBottom() {
    const container = document.getElementById('messagesContainer');
    if (container) {
        container.scrollTop = container.scrollHeight;
    }
}

// نمایش اعلان
function showNotification(text, type = 'info') {
    // حذف اعلان قبلی
    const oldNotification = document.querySelector('.notification');
    if (oldNotification) oldNotification.remove();
    
    // ایجاد اعلان جدید
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        left: 50%;
        transform: translateX(-50%);
        background: ${type === 'success' ? '#1a7f37' : 
                    type === 'error' ? '#da3633' : 
                    type === 'warning' ? '#d29922' : '#2d3743'};
        color: white;
        padding: 10px 20px;
        border-radius: 6px;
        font-size: 14px;
        z-index: 2000;
        animation: slideDown 0.3s ease-out;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    `;
    
    notification.textContent = text;
    document.body.appendChild(notification);
    
    // حذف خودکار
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(-50%) translateY(-10px)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }
    }, 3000);
}

// استایل‌های اضافی برای انیمیشن
const additionalStyles = `
    <style>
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateX(-50%) translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(-50%) translateY(0);
            }
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
`;

document.head.insertAdjacentHTML('beforeend', additionalStyles);