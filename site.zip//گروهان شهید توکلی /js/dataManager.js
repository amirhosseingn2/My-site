// dataManager.js
const initializeData = () => {
    // داده‌های اولیه
    const defaults = {
        rations: [],
        chatMessages: [],
        news: [],
        topUsers: [],
        events: [],
        dorms: { dorm1: [], dorm2: [], dorm3: [], dorm4: [] },
        punishments: [],
        rationDeadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 روز بعد
    };
    
    Object.keys(defaults).forEach(key => {
        if (!localStorage.getItem(key)) {
            localStorage.setItem(key, JSON.stringify(defaults[key]));
        }
    });
};

const getAllData = () => {
    return {
        users: JSON.parse(localStorage.getItem('users') || '[]'),
        rations: JSON.parse(localStorage.getItem('rations') || '[]'),
        chatMessages: JSON.parse(localStorage.getItem('chatMessages') || '[]'),
        news: JSON.parse(localStorage.getItem('news') || '[]'),
        topUsers: JSON.parse(localStorage.getItem('topUsers') || '[]'),
        events: JSON.parse(localStorage.getItem('events') || '[]'),
        dorms: JSON.parse(localStorage.getItem('dorms') || '{}'),
        punishments: JSON.parse(localStorage.getItem('punishments') || '[]')
    };
};

const backupData = () => {
    const allData = getAllData();
    allData.backupDate = new Date().toISOString();
    return JSON.stringify(allData, null, 2);
};

const restoreData = (backupString) => {
    try {
        const backup = JSON.parse(backupString);
        Object.keys(backup).forEach(key => {
            if (key !== 'backupDate') {
                localStorage.setItem(key, JSON.stringify(backup[key]));
            }
        });
        return { success: true, message: 'داده‌ها با موفقیت بازیابی شدند' };
    } catch (error) {
        return { success: false, message: 'خطا در بازیابی داده‌ها' };
    }
};