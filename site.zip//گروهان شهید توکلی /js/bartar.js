// ==================== مدیریت صفحه نفرات برتر ====================

// داده‌های اولیه
let allChampions = [];
let currentFilter = 'all';
let currentUser = null;

// رشته‌های تحصیلی
const academicMajors = [
    'مخابرات',
    'الکترونیک',
    'جنگال',
    'کامپیوتر',
    'سایبر',
    'پهباد',
    'خلبانی',
    'هوافضا',
    'تعمیر و نگهداری'
];

// دسته‌های ورزشی
const sportsCategories = [
    'فوتبال',
    'والیبال',
    'بسکتبال',
    'شنا',
    'دو و میدانی',
    'کشتی',
    'تیراندازی',
    'کاراته',
    'تنیس روی میز'
];

// دسته‌های نظامی
const militaryCategories = [
    'آمادگی رزمی',
    'تیراندازی نظامی',
    'نقشه‌خوانی',
    'فرماندهی',
    'راهبری',
    'مهندسی رزمی',
    'اطلاعات عملیات'
];

// ==================== بارگذاری اولیه ====================
document.addEventListener('DOMContentLoaded', function() {
    console.log("🏆 صفحه نفرات برتر بارگذاری شد");
    
    // بررسی ورود کاربر
    checkUserAccess();
    
    // بارگذاری داده‌ها
    loadChampionsData();
    
    // تنظیم رویدادها
    setupEventListeners();
    
    // به‌روزرسانی آمار
    updateStats();
});

// بررسی دسترسی کاربر
function checkUserAccess() {
    const userData = localStorage.getItem('currentUser');
    if (!userData) {
        window.location.href = 'index.html';
        return;
    }
    
    currentUser = JSON.parse(userData);
    console.log("👤 کاربر:", currentUser.username);
}

// بارگذاری داده‌های نفرات برتر
function loadChampionsData() {
    // بارگذاری از localStorage
    allChampions = JSON.parse(localStorage.getItem('topChampions') || '[]');
    
    // اگر داده‌ای نیست، نمونه ایجاد کن
    if (allChampions.length === 0) {
        createSampleChampions();
    }
    
    console.log(`🏆 ${allChampions.length} نفر برتر بارگذاری شد`);
    
    // نمایش نفرات برتر
    displayChampions();
}

// ایجاد داده‌های نمونه
function createSampleChampions() {
    const sampleChampions = [
        // نفرات برتر تحصیلی
        {
            id: 1,
            category: 'academic',
            major: 'مخابرات',
            name: 'امیرحسین محمدی',
            rank: 1,
            studentId: '403825663',
            avatar: 'ا',
            achievements: [
                'معدل ترم: ۱۹.۸۵',
                'رتبه اول مسابقات علمی',
                'مقاله منتشر شده در کنفرانس ملی'
            ],
            description: 'دانشجوی برتر رشته مخابرات با عملکرد درخشان در دروس تخصصی',
            points: 985,
            lastUpdate: new Date().toISOString()
        },
        {
            id: 2,
            category: 'academic',
            major: 'الکترونیک',
            name: 'محمد رضایی',
            rank: 1,
            studentId: '403825664',
            avatar: 'م',
            achievements: [
                'معدل ترم: ۱۹.۷۵',
                'پروژه عملیاتی سیستم‌های دیجیتال',
                'اختراع ثبت شده'
            ],
            description: 'متخصص در زمینه طراحی مدارهای الکترونیکی پیشرفته',
            points: 945,
            lastUpdate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
            id: 3,
            category: 'academic',
            major: 'کامپیوتر',
            name: 'علی کریمی',
            rank: 1,
            studentId: '403825665',
            avatar: 'ع',
            achievements: [
                'معدل ترم: ۲۰',
                'توسعه نرم‌افزار مدیریت گروهان',
                'قهرمان مسابقات برنامه‌نویسی'
            ],
            description: 'برنامه‌نویس خبره با تسلط بر چندین زبان برنامه‌نویسی',
            points: 1025,
            lastUpdate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
        },
        
        // نفرات برتر ورزشی
        {
            id: 4,
            category: 'sports',
            major: 'فوتبال',
            name: 'حسین احمدی',
            rank: 1,
            studentId: '403825666',
            avatar: 'ح',
            achievements: [
                'کاپیتان تیم فوتبال گروهان',
                'بهترین گلزن مسابقات',
                'مربی‌گری سطح یک'
            ],
            description: 'بازیکن مطرح و کاپیتان تیم فوتبال با روحیه رهبری بالا',
            points: 875,
            lastUpdate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
            id: 5,
            category: 'sports',
            major: 'شنا',
            name: 'رضا قربانی',
            rank: 1,
            studentId: '403825667',
            avatar: 'ر',
            achievements: [
                'رکورددار شنای گروهان',
                'مدال طلا مسابقات کشوری',
                'مربی شنای استانی'
            ],
            description: 'شناگر ممتاز با کسب مدال‌های متعدد در مسابقات',
            points: 925,
            lastUpdate: new Date().toISOString()
        },
        
        // نفرات برتر نظامی
        {
            id: 6,
            category: 'military',
            major: 'تیراندازی نظامی',
            name: 'سید محمد حسینی',
            rank: 1,
            studentId: '403825668',
            avatar: 'س',
            achievements: [
                'قهرمان تیراندازی گروهان',
                'مربی تیراندازی',
                'رکورددار امتیاز در تیراندازی'
            ],
            description: 'تک‌تیرانداز زبده با دقت و مهارت بالا',
            points: 965,
            lastUpdate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
            id: 7,
            category: 'military',
            major: 'آمادگی رزمی',
            name: 'مهدی نوری',
            rank: 1,
            studentId: '403825669',
            avatar: 'م',
            achievements: [
                'رتبه اول آمادگی رزمی',
                'مدال نقره مسابقات کشوری',
                'مربی بدنسازی نظامی'
            ],
            description: 'ورزشکار حرفه‌ای با آمادگی جسمانی بالا',
            points: 890,
            lastUpdate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
        }
    ];
    
    allChampions = sampleChampions;
    localStorage.setItem('topChampions', JSON.stringify(sampleChampions));
    console.log("✅ داده‌های نمونه نفرات برتر ایجاد شدند");
}

// تنظیم رویدادها
function setupEventListeners() {
    // دکمه فیلترها
    const filterTabs = document.querySelectorAll('.filter-tab');
    filterTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // حذف کلاس active از همه
            filterTabs.forEach(t => t.classList.remove('active'));
            // اضافه کردن به دکمه کلیک شده
            this.classList.add('active');
            
            // اعمال فیلتر
            currentFilter = this.getAttribute('data-filter');
            filterChampions();
        });
    });
    
    // جستجو
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            filterChampions();
        });
    }
    
    // دکمه به‌روزرسانی
    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            loadChampionsData();
            showNotification('لیست نفرات برتر به‌روزرسانی شد', 'success');
        });
    }
    
    // کلیک روی کارت‌ها
    document.addEventListener('click', function(e) {
        if (e.target.closest('.champion-card')) {
            const card = e.target.closest('.champion-card');
            const championId = card.getAttribute('data-id');
            if (championId) {
                showChampionDetails(championId);
            }
        }
    });
}

// فیلتر کردن نفرات برتر
function filterChampions() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    
    let filtered = allChampions;
    
    // اعمال فیلتر دسته
    if (currentFilter !== 'all') {
        if (currentFilter === 'top3') {
            // ۳ نفر برتر بر اساس امتیاز
            filtered = [...allChampions]
                .sort((a, b) => b.points - a.points)
                .slice(0, 3);
        } else {
            filtered = allChampions.filter(champ => champ.category === currentFilter);
        }
    }
    
    // اعمال فیلتر جستجو
    if (searchTerm) {
        filtered = filtered.filter(champ =>
            champ.name.toLowerCase().includes(searchTerm) ||
            champ.major.toLowerCase().includes(searchTerm) ||
            champ.description.toLowerCase().includes(searchTerm)
        );
    }
    
    // نمایش نتایج
    displayChampions(filtered);
    
    // نمایش/مخفی کردن حالت خالی
    const emptyState = document.getElementById('emptyState');
    if (emptyState) {
        emptyState.style.display = filtered.length === 0 ? 'block' : 'none';
    }
}

// نمایش نفرات برتر
function displayChampions(champions = allChampions) {
    const grid = document.getElementById('championsGrid');
    if (!grid) return;
    
    if (champions.length === 0) {
        grid.innerHTML = '';
        return;
    }
    
    // مرتب‌سازی بر اساس رتبه و امتیاز
    const sortedChampions = [...champions].sort((a, b) => {
        if (a.rank !== b.rank) return a.rank - b.rank;
        return b.points - a.points;
    });
    
    let championsHTML = '';
    
    sortedChampions.forEach(champion => {
        // رنگ دسته
        let categoryClass = '';
        let categoryIcon = '';
        let categoryLabel = '';
        
        switch(champion.category) {
            case 'academic':
                categoryClass = 'category-academic';
                categoryIcon = 'fa-user-graduate';
                categoryLabel = 'تحصیلی';
                break;
            case 'sports':
                categoryClass = 'category-academic'; // تغییر نکرده
                categoryIcon = 'fa-futbol';
                categoryLabel = 'ورزشی';
                break;
            case 'military':
                categoryClass = 'category-military';
                categoryIcon = 'fa-shield-alt';
                categoryLabel = 'نظامی';
                break;
            default:
                categoryClass = 'category-academic';
                categoryIcon = 'fa-medal';
                categoryLabel = 'برتر';
        }
        
        // رتبه
        const rankText = champion.rank === 1 ? '🥇' : 
                        champion.rank === 2 ? '🥈' : 
                        champion.rank === 3 ? '🥉' : `#${champion.rank}`;
        
        // تاریخ آخرین به‌روزرسانی
        const lastUpdate = new Date(champion.lastUpdate);
        const timeAgo = getTimeAgo(lastUpdate);
        
        championsHTML += `
            <div class="champion-card" data-id="${champion.id}">
                <div class="champion-header ${categoryClass}">
                    <div class="champion-category">
                        <i class="fas ${categoryIcon}"></i>
                        ${categoryLabel} - ${champion.major}
                    </div>
                    <h3 class="champion-title">نفر برتر ${champion.major}</h3>
                    <div class="champion-icon">
                        <i class="fas ${categoryIcon}"></i>
                    </div>
                    
                    <div class="ranking-badge">
                        ${rankText}
                    </div>
                </div>
                
                <div class="champion-content">
                    <div class="champion-info">
                        <div class="champion-avatar">
                            ${champion.avatar}
                        </div>
                        <div class="champion-details">
                            <h4 class="champion-name">${champion.name}</h4>
                            <div class="champion-stats">
                                <div class="stat-item">
                                    <i class="fas fa-id-card"></i>
                                    <span>${champion.studentId}</span>
                                </div>
                                <div class="stat-item">
                                    <i class="fas fa-star"></i>
                                    <span>${champion.points} امتیاز</span>
                                </div>
                                <div class="stat-item">
                                    <i class="fas fa-clock"></i>
                                    <span>${timeAgo}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <p class="champion-description">
                        ${champion.description}
                    </p>
                    
                    <div class="achievements">
                        <h4><i class="fas fa-trophy"></i> دستاوردها</h4>
                        <ul class="achievements-list">
                            ${champion.achievements.map(achievement => 
                                `<li><i class="fas fa-check-circle"></i> ${achievement}</li>`
                            ).join('')}
                        </ul>
                    </div>
                </div>
            </div>
        `;
    });
    
    grid.innerHTML = championsHTML;
}

// محاسبه زمان گذشته
function getTimeAgo(date) {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'همین الان';
    if (diffMins < 60) return `${diffMins} دقیقه پیش`;
    if (diffHours < 24) return `${diffHours} ساعت پیش`;
    if (diffDays < 7) return `${diffDays} روز پیش`;
    
    return date.toLocaleDateString('fa-IR');
}

// نمایش جزئیات نفر برتر
function showChampionDetails(championId) {
    const champion = allChampions.find(c => c.id === parseInt(championId));
    if (!champion) return;
    
    // در اینجا می‌توانید یک مودال برای نمایش جزئیات بیشتر ایجاد کنید
    const details = `
        🏆 نفر برتر ${champion.major}
        
        👤 نام: ${champion.name}
        🆔 شماره دانشجویی: ${champion.studentId}
        ⭐ امتیاز: ${champion.points}
        🥇 رتبه: ${champion.rank}
        
        📝 توضیحات:
        ${champion.description}
        
        🏅 دستاوردها:
        ${champion.achievements.map(a => `• ${a}`).join('\n')}
        
        📅 آخرین به‌روزرسانی: ${new Date(champion.lastUpdate).toLocaleDateString('fa-IR')}
    `;
    
    alert(details);
}

// به‌روزرسانی آمار
function updateStats() {
    // تعداد نفرات برتر تحصیلی
    const academicCount = allChampions.filter(c => c.category === 'academic').length;
    document.getElementById('totalAcademic').textContent = academicCount;
    
    // تعداد نفرات برتر ورزشی
    const sportsCount = allChampions.filter(c => c.category === 'sports').length;
    document.getElementById('totalSports').textContent = sportsCount;
    
    // تعداد نفرات برتر نظامی
    const militaryCount = allChampions.filter(c => c.category === 'military').length;
    document.getElementById('totalMilitary').textContent = militaryCount;
    
    // مجموع
    const totalCount = allChampions.length;
    document.getElementById('totalChampions').textContent = totalCount;
}

// نمایش اعلان
function showNotification(text, type = 'info') {
    // حذف اعلان قبلی
    const oldNotification = document.querySelector('.notification');
    if (oldNotification) oldNotification.remove();
    
    // ایجاد اعلان جدید
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: ${type === 'success' ? '#27ae60' : 
                    type === 'error' ? '#e74c3c' : 
                    type === 'warning' ? '#f39c12' : '#3498db'};
        color: white;
        padding: 12px 24px;
        border-radius: 8px;
        font-size: 14px;
        z-index: 2000;
        animation: slideDown 0.3s ease-out;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 300px;
        max-width: 500px;
    `;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        info: 'fa-info-circle',
        warning: 'fa-exclamation-triangle'
    };
    
    notification.innerHTML = `
        <i class="fas ${icons[type]}"></i>
        <span>${text}</span>
    `;
    
    document.body.appendChild(notification);
    
    // حذف خودکار
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(-50%) translateY(-10px)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }
    }, 3000);
}

// استایل‌های اضافی برای انیمیشن
const additionalStyles = `
    <style>
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateX(-50%) translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(-50%) translateY(0);
            }
        }
        
        .champion-card {
            animation: fadeInUp 0.5s ease-out;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
`;

document.head.insertAdjacentHTML('beforeend', additionalStyles);