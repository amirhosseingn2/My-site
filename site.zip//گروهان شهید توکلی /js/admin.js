// ==================== مدیریت بخش ادمین ====================

// بارگذاری پنل مدیریت
function loadAdminPanel() {
    if (!checkPermission('admin')) {
        window.location.href = '../dashboard.html';
        return;
    }
    
    const user = getCurrentUser();
    
    const content = `
        <div class="content-header">
            <h1>پنل مدیریت سیستم</h1>
            <p>کاربر: ${user.fullName} | سطح دسترسی: مدیر کل</p>
        </div>
        
        <div class="quick-stats">
            <div class="stat-card" onclick="window.location.href='admin/users.html'">
                <i class="fas fa-users"></i>
                <div class="stat-value">${getUserCount()}</div>
                <div class="stat-label">کاربران فعال</div>
            </div>
            <div class="stat-card" onclick="window.location.href='admin/amar.html'">
                <i class="fas fa-chart-bar"></i>
                <div class="stat-value">${getRationCount()}</div>
                <div class="stat-label">آمار ثبت شده</div>
            </div>
            <div class="stat-card" onclick="window.location.href='admin/khab.html'">
                <i class="fas fa-bed"></i>
                <div class="stat-value">${getDormOccupancy()}</div>
                <div class="stat-label">خوابگاه اشغال شده</div>
            </div>
            <div class="stat-card" onclick="window.location.href='admin/logs.html'">
                <i class="fas fa-history"></i>
                <div class="stat-value">${getLogCount()}</div>
                <div class="stat-label">لاگ فعالیت</div>
            </div>
        </div>
        
        <div class="card-grid">
            <!-- مدیریت کاربران -->
            <div class="card">
                <h3><i class="fas fa-users"></i> مدیریت کاربران</h3>
                <button onclick="window.location.href='admin/users.html'" class="btn-primary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-list"></i> مشاهده کاربران
                </button>
                <button onclick="showAddUserForm()" class="btn-secondary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-user-plus"></i> افزودن کاربر جدید
                </button>
                <button onclick="exportUsersToCSV()" class="btn-secondary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-download"></i> خروجی CSV
                </button>
            </div>
            
            <!-- تنظیمات سیستم -->
            <div class="card">
                <h3><i class="fas fa-cogs"></i> تنظیمات سیستم</h3>
                <button onclick="window.location.href='admin/nzm.html'" class="btn-primary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-sliders-h"></i> تنظیمات اصلی
                </button>
                <button onclick="manageSecretaryAccess()" class="btn-secondary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-user-shield"></i> تعیین دسترسی منشی
                </button>
                <button onclick="setRationDeadline()" class="btn-secondary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-clock"></i> تعیین مهلت آمار جیره
                </button>
            </div>
            
            <!-- گزارشات و آمار -->
            <div class="card">
                <h3><i class="fas fa-chart-line"></i> گزارشات و آمار</h3>
                <button onclick="window.location.href='admin/amar.html'" class="btn-primary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-chart-bar"></i> گزارش آمار جیره
                </button>
                <button onclick="showRationReport()" class="btn-secondary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-file-excel"></i> خروجی اکسل
                </button>
                <button onclick="showUserActivityReport()" class="btn-secondary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-user-clock"></i> گزارش فعالیت کاربران
                </button>
            </div>
            
            <!-- مدیریت محتوا -->
            <div class="card">
                <h3><i class="fas fa-newspaper"></i> مدیریت محتوا</h3>
                <button onclick="window.location.href='admin/khabar.html'" class="btn-primary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-bullhorn"></i> مدیریت اخبار
                </button>
                <button onclick="window.location.href='admin/bartar.html'" class="btn-secondary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-trophy"></i> مدیریت نفرات برتر
                </button>
                <button onclick="window.location.href='admin/events.html'" class="btn-secondary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-calendar-alt"></i> مدیریت رویدادها
                </button>
            </div>
            
            <!-- مدیریت خوابگاه‌ها -->
            <div class="card">
                <h3><i class="fas fa-home"></i> مدیریت خوابگاه‌ها</h3>
                <button onclick="window.location.href='admin/khab.html'" class="btn-primary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-bed"></i> مشاهده خوابگاه‌ها
                </button>
                <button onclick="showDormManagement()" class="btn-secondary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-users"></i> توزیع کاربران
                </button>
                <button onclick="autoAssignDorms()" class="btn-secondary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-random"></i> توزیع خودکار
                </button>
            </div>
            
            <!-- ابزارهای مدیریتی -->
            <div class="card">
                <h3><i class="fas fa-tools"></i> ابزارهای مدیریتی</h3>
                <button onclick="window.location.href='admin/backup.html'" class="btn-primary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-database"></i> پشتیبان‌گیری
                </button>
                <button onclick="window.location.href='admin/logs.html'" class="btn-secondary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-clipboard-list"></i> مشاهده لاگ‌ها
                </button>
                <button onclick="clearCache()" class="btn-secondary" style="margin: 5px; width: 100%;">
                    <i class="fas fa-broom"></i> پاک‌سازی کش
                </button>
                <button onclick="resetSystemConfirm()" class="btn-danger" style="margin: 5px; width: 100%;">
                    <i class="fas fa-trash"></i> ریست سیستم
                </button>
            </div>
        </div>
        
        <div id="adminContent" style="margin-top: 30px;"></div>
        
        <div id="adminMessages" style="margin-top: 20px;"></div>
    `;
    
    document.querySelector('.main-content').innerHTML = content;
}

// ==================== توابع کمکی ====================

// بررسی دسترسی
function checkPermission(requiredRole) {
    const user = getCurrentUser();
    if (!user) {
        window.location.href = '../index.html';
        return false;
    }
    
    if (user.role !== requiredRole && user.role !== 'admin') {
        showAdminMessage('شما دسترسی لازم برای این بخش را ندارید.', 'error');
        return false;
    }
    
    return true;
}

// دریافت کاربر جاری
function getCurrentUser() {
    const userData = localStorage.getItem('currentUser');
    return userData ? JSON.parse(userData) : null;
}

// تعداد کاربران
function getUserCount() {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    return users.filter(u => u.isActive !== false && u.role !== 'admin').length;
}

// تعداد آمار ثبت شده
function getRationCount() {
    const rations = JSON.parse(localStorage.getItem('rations') || '[]');
    return rations.length;
}

// اشغالی خوابگاه‌ها
function getDormOccupancy() {
    const dorms = JSON.parse(localStorage.getItem('dorms') || '{}');
    let occupied = 0;
    for (let i = 1; i <= 4; i++) {
        if (dorms[`dorm${i}`] && dorms[`dorm${i}`].length > 0) {
            occupied++;
        }
    }
    return occupied;
}

// تعداد لاگ‌ها
function getLogCount() {
    const logs = JSON.parse(localStorage.getItem('adminLogs') || '[]');
    return logs.length;
}

// ==================== نمایش فرم افزودن کاربر جدید ====================
function showAddUserForm() {
    if (!checkPermission('admin')) return;
    
    const formHTML = `
        <div class="card">
            <h3><i class="fas fa-user-plus"></i> افزودن کاربر جدید</h3>
            <form id="addUserForm">
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                    <div class="input-group">
                        <label for="fullName"><i class="fas fa-user"></i> نام و نام خانوادگی *</label>
                        <input type="text" id="fullName" required placeholder="مثال: علی محمدی">
                    </div>
                    
                    <div class="input-group">
                        <label for="newUsername"><i class="fas fa-at"></i> نام کاربری *</label>
                        <input type="text" id="newUsername" required placeholder="مثال: alimohammadi">
                    </div>
                    
                    <div class="input-group">
                        <label for="newPassword"><i class="fas fa-lock"></i> رمز عبور *</label>
                        <input type="password" id="newPassword" required minlength="6" placeholder="حداقل ۶ کاراکتر">
                    </div>
                    
                    <div class="input-group">
                        <label for="confirmPassword"><i class="fas fa-lock"></i> تکرار رمز عبور *</label>
                        <input type="password" id="confirmPassword" required placeholder="تکرار رمز عبور">
                    </div>
                    
                    <div class="input-group">
                        <label for="dormNumber"><i class="fas fa-home"></i> شماره خوابگاه *</label>
                        <select id="dormNumber" required>
                            <option value="">انتخاب کنید</option>
                            <option value="1">خوابگاه ۱</option>
                            <option value="2">خوابگاه ۲</option>
                            <option value="3">خوابگاه ۳</option>
                            <option value="4">خوابگاه ۴</option>
                            <option value="0">بدون خوابگاه</option>
                        </select>
                    </div>
                    
                    <div class="input-group">
                        <label for="department"><i class="fas fa-graduation-cap"></i> رشته تحصیلی *</label>
                        <select id="department" required>
                            <option value="">انتخاب کنید</option>
                            <option value="مخابرات">مخابرات</option>
                            <option value="الکترونیک">الکترونیک</option>
                            <option value="جنگال">جنگال</option>
                            <option value="کامپیوتر">کامپیوتر</option>
                            <option value="سایبر">سایبر</option>
                            <option value="پهباد">پهباد</option>
                            <option value="خلبانی">خلبانی</option>
                            <option value="هوافضا">هوافضا</option>
                            <option value="تعمیر و نگهداری">تعمیر و نگهداری</option>
                            <option value="سایر">سایر</option>
                        </select>
                    </div>
                    
                    <div class="input-group">
                        <label for="userRole"><i class="fas fa-user-tag"></i> نقش کاربر *</label>
                        <select id="userRole" required>
                            <option value="user">کاربر عادی</option>
                            <option value="secretary">منشی</option>
                            <option value="admin">مدیر (ادمین)</option>
                        </select>
                    </div>
                    
                    <div class="input-group">
                        <label for="studentId"><i class="fas fa-id-card"></i> شماره دانشجویی (اختیاری)</label>
                        <input type="text" id="studentId" placeholder="مثال: 403825663">
                    </div>
                </div>
                
                <div style="margin-top: 20px;">
                    <label class="checkbox-label">
                        <input type="checkbox" id="sendWelcome" checked>
                        <span>ارسال پیام خوش‌آمدگویی به کاربر</span>
                    </label>
                </div>
                
                <div style="margin-top: 20px; display: flex; gap: 10px;">
                    <button type="submit" class="btn-success">
                        <i class="fas fa-save"></i> ذخیره کاربر
                    </button>
                    <button type="button" onclick="loadAdminPanel()" class="btn-secondary">
                        <i class="fas fa-times"></i> انصراف
                    </button>
                </div>
            </form>
        </div>
    `;
    
    document.getElementById('adminContent').innerHTML = formHTML;
    
    document.getElementById('addUserForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const password = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        
        if (password !== confirmPassword) {
            showAdminMessage('رمز عبور و تکرار آن مطابقت ندارند', 'error');
            return;
        }
        
        if (password.length < 6) {
            showAdminMessage('رمز عبور باید حداقل ۶ کاراکتر باشد', 'error');
            return;
        }
        
        const userData = {
            fullName: document.getElementById('fullName').value,
            username: document.getElementById('newUsername').value,
            password: password,
            dormNumber: document.getElementById('dormNumber').value,
            department: document.getElementById('department').value,
            role: document.getElementById('userRole').value,
            studentId: document.getElementById('studentId').value || null,
            isActive: true,
            createdAt: new Date().toISOString()
        };
        
        const result = addNewUser(userData);
        
        if (result.success) {
            showAdminMessage(result.message, 'success');
            
            // ارسال پیام خوش‌آمدگویی
            if (document.getElementById('sendWelcome').checked) {
                sendWelcomeMessage(userData.username, userData.fullName, userData.password);
            }
            
            setTimeout(() => {
                loadAdminPanel();
            }, 1500);
        } else {
            showAdminMessage(result.message, 'error');
        }
    });
}

// افزودن کاربر جدید به سیستم
function addNewUser(userData) {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    // بررسی تکراری نبودن نام کاربری
    if (users.find(u => u.username === userData.username)) {
        return { success: false, message: 'این نام کاربری قبلاً ثبت شده است' };
    }
    
    // ایجاد ID جدید
    const newId = Date.now();
    
    const newUser = {
        id: newId,
        fullName: userData.fullName,
        username: userData.username,
        password: userData.password,
        dormNumber: userData.dormNumber,
        department: userData.department,
        role: userData.role,
        studentId: userData.studentId,
        isActive: userData.isActive,
        createdAt: userData.createdAt,
        lastLogin: null,
        loginCount: 0
    };
    
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    // اضافه کردن به خوابگاه
    if (userData.dormNumber !== '0') {
        addUserToDorm(userData.dormNumber, userData.username, userData.fullName, userData.department);
    }
    
    // ایجاد لاگ
    addAdminLog(`کاربر جدید "${userData.fullName}" با نام کاربری "${userData.username}" اضافه شد`);
    
    return { success: true, message: 'کاربر با موفقیت اضافه شد' };
}

// ارسال پیام خوش‌آمدگویی
function sendWelcomeMessage(username, fullName, password) {
    const welcomeMessages = JSON.parse(localStorage.getItem('welcomeMessages') || '[]');
    
    welcomeMessages.push({
        to: username,
        subject: 'خوش آمدید به سیستم گروهان شهید توکلی',
        message: `سلام ${fullName} عزیز،

به سیستم مدیریت گروهان شهید توکلی خوش آمدید.

🔐 اطلاعات ورود شما:
نام کاربری: ${username}
رمز عبور: ${password}

لطفاً پس از اولین ورود، رمز عبور خود را تغییر دهید.

با احترام،
مدیریت سیستم`,
        sentAt: new Date().toISOString(),
        read: false
    });
    
    localStorage.setItem('welcomeMessages', JSON.stringify(welcomeMessages));
}

// ==================== مدیریت خوابگاه‌ها ====================
function showDormManagement() {
    if (!checkPermission('admin')) return;
    
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const dormData = JSON.parse(localStorage.getItem('dormData') || '{"capacities": [30,30,30,30], "assignments": {}}');
    
    let content = `
        <div class="card">
            <h3><i class="fas fa-home"></i> مدیریت خوابگاه‌ها</h3>
            
            <div style="margin-bottom: 20px;">
                <h4><i class="fas fa-sliders-h"></i> تنظیم ظرفیت خوابگاه‌ها</h4>
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-top: 15px;">
    `;
    
    for (let i = 1; i <= 4; i++) {
        const capacity = dormData.capacities[i-1] || 30;
        const usersInDorm = users.filter(u => u.dormNumber === i.toString()).length;
        const percent = Math.round((usersInDorm / capacity) * 100);
        
        content += `
            <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center;">
                <div style="font-weight: bold; margin-bottom: 10px; color: #2c3e50;">
                    خوابگاه ${i}
                </div>
                <div style="font-size: 24px; color: #3498db; margin: 10px 0;">
                    ${usersInDorm}/${capacity}
                </div>
                <div style="height: 10px; background: #e0e0e0; border-radius: 5px; overflow: hidden;">
                    <div style="width: ${percent}%; height: 100%; background: ${percent > 90 ? '#e74c3c' : percent > 70 ? '#f39c12' : '#27ae60'};"></div>
                </div>
                <div style="margin-top: 10px;">
                    <input type="number" id="dorm${i}Capacity" value="${capacity}" min="1" max="100" style="width: 80px; padding: 5px; text-align: center; border: 1px solid #ddd; border-radius: 4px;">
                </div>
            </div>
        `;
    }
    
    content += `
                </div>
                <div style="margin-top: 15px;">
                    <button onclick="updateDormCapacities()" class="btn-primary">
                        <i class="fas fa-save"></i> ذخیره ظرفیت‌ها
                    </button>
                </div>
            </div>
            
            <div style="margin-top: 20px;">
                <h4><i class="fas fa-users"></i> توزیع کاربران</h4>
                <div style="display: flex; gap: 10px; margin-top: 15px;">
                    <button onclick="autoAssignDorms()" class="btn-success">
                        <i class="fas fa-random"></i> توزیع خودکار
                    </button>
                    <button onclick="showManualAssignment()" class="btn-secondary">
                        <i class="fas fa-user-edit"></i> توزیع دستی
                    </button>
                    <button onclick="clearDormAssignments()" class="btn-danger">
                        <i class="fas fa-trash"></i> پاک‌سازی همه
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('adminContent').innerHTML = content;
}

// به‌روزرسانی ظرفیت خوابگاه‌ها
function updateDormCapacities() {
    const capacities = [
        parseInt(document.getElementById('dorm1Capacity').value) || 30,
        parseInt(document.getElementById('dorm2Capacity').value) || 30,
        parseInt(document.getElementById('dorm3Capacity').value) || 30,
        parseInt(document.getElementById('dorm4Capacity').value) || 30
    ];
    
    let dormData = JSON.parse(localStorage.getItem('dormData') || '{}');
    dormData.capacities = capacities;
    dormData.updatedAt = new Date().toISOString();
    
    localStorage.setItem('dormData', JSON.stringify(dormData));
    showAdminMessage('ظرفیت خوابگاه‌ها با موفقیت به‌روزرسانی شد', 'success');
    
    setTimeout(() => {
        showDormManagement();
    }, 1000);
}

// توزیع خودکار خوابگاه‌ها
function autoAssignDorms() {
    if (!checkPermission('admin')) return;
    
    if (!confirm('آیا می‌خواهید کاربران به صورت تصادفی در خوابگاه‌ها توزیع شوند؟')) {
        return;
    }
    
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const dormData = JSON.parse(localStorage.getItem('dormData') || '{"capacities": [30,30,30,30]}');
    
    // فقط کاربران عادی (نه ادمین و منشی)
    const regularUsers = users.filter(u => u.role === 'user' && u.isActive !== false);
    
    // پاکسازی تخصیص قبلی
    regularUsers.forEach(user => {
        user.dormNumber = '0';
    });
    
    // توزیع تصادفی
    const capacities = dormData.capacities;
    const dormAssignments = {1: [], 2: [], 3: [], 4: []};
    
    // اولویت‌بندی کاربران بدون خوابگاه
    const unassignedUsers = regularUsers.filter(u => u.dormNumber === '0');
    
    unassignedUsers.forEach(user => {
        // پیدا کردن خوابگاهی که کمترین پراکندگی را دارد
        let bestDorm = 1;
        let minOccupancy = Infinity;
        
        for (let dorm = 1; dorm <= 4; dorm++) {
            const currentCount = dormAssignments[dorm].length;
            const capacity = capacities[dorm-1];
            
            if (currentCount < capacity && currentCount < minOccupancy) {
                minOccupancy = currentCount;
                bestDorm = dorm;
            }
        }
        
        // اختصاص کاربر به بهترین خوابگاه
        user.dormNumber = bestDorm.toString();
        dormAssignments[bestDorm].push(user.username);
    });
    
    // ذخیره تغییرات
    localStorage.setItem('users', JSON.stringify(users));
    
    // به‌روزرسانی اطلاعات خوابگاه
    updateDormsData(dormAssignments);
    
    addAdminLog('توزیع خودکار خوابگاه‌ها انجام شد');
    showAdminMessage('کاربران با موفقیت در خوابگاه‌ها توزیع شدند', 'success');
    
    setTimeout(() => {
        showDormManagement();
    }, 1500);
}

// به‌روزرسانی اطلاعات خوابگاه
function updateDormsData(assignments) {
    let dormsData = {};
    
    for (let dorm = 1; dorm <= 4; dorm++) {
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        const dormUsers = users.filter(u => u.dormNumber === dorm.toString());
        
        dormsData[`dorm${dorm}`] = dormUsers.map(user => ({
            username: user.username,
            fullName: user.fullName,
            department: user.department,
            studentId: user.studentId
        }));
    }
    
    localStorage.setItem('dorms', JSON.stringify(dormsData));
}

// ==================== گزارش آمار جیره ====================
function showRationReport() {
    if (!checkPermission('admin')) return;
    
    const rations = JSON.parse(localStorage.getItem('rations') || '[]');
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const deadline = localStorage.getItem('rationDeadline') ? new Date(JSON.parse(localStorage.getItem('rationDeadline'))) : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    
    const submittedCount = rations.length;
    const totalUsers = users.filter(u => u.role === 'user' && u.isActive !== false).length;
    const pendingCount = totalUsers - submittedCount;
    const submissionRate = totalUsers > 0 ? Math.round((submittedCount / totalUsers) * 100) : 0;
    
    let reportHTML = `
        <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h3><i class="fas fa-chart-bar"></i> گزارش آمار جیره</h3>
                <div>
                    <button onclick="exportRationData()" class="btn-secondary">
                        <i class="fas fa-file-excel"></i> خروجی اکسل
                    </button>
                    <button onclick="sendReminders()" class="btn-warning">
                        <i class="fas fa-bell"></i> ارسال یادآوری
                    </button>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 20px;">
                <div class="stat-card-small" style="background: #e8f4fc;">
                    <div class="stat-value-small">${totalUsers}</div>
                    <div class="stat-label-small">کل کاربران</div>
                </div>
                <div class="stat-card-small" style="background: #e8f6ef;">
                    <div class="stat-value-small">${submittedCount}</div>
                    <div class="stat-label-small">ثبت‌شده</div>
                </div>
                <div class="stat-card-small" style="background: #fff4e6;">
                    <div class="stat-value-small">${pendingCount}</div>
                    <div class="stat-label-small">ثبت‌نشده</div>
                </div>
                <div class="stat-card-small" style="background: #f4ecf7;">
                    <div class="stat-value-small">${submissionRate}%</div>
                    <div class="stat-label-small">نرخ ثبت</div>
                </div>
            </div>
            
            <div style="margin-bottom: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                <p><strong><i class="fas fa-clock"></i> مهلت ثبت:</strong> ${deadline.toLocaleDateString('fa-IR')} ساعت ${deadline.toLocaleTimeString('fa-IR', {hour: '2-digit', minute:'2-digit'})}</p>
                <p><strong><i class="fas fa-info-circle"></i> وضعیت:</strong> ${new Date() > deadline ? '❌ مهلت به پایان رسیده' : '✅ در حال ثبت'}</p>
            </div>
            
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ردیف</th>
                            <th>نام کامل</th>
                            <th>نام کاربری</th>
                            <th>خوابگاه</th>
                            <th>رشته</th>
                            <th>صبحانه هفته</th>
                            <th>پنج‌شنبه</th>
                            <th>جمعه</th>
                            <th>تاریخ ثبت</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
    `;
    
    if (rations.length === 0) {
        reportHTML += `
            <tr>
                <td colspan="10" style="text-align: center; padding: 30px; color: #666;">
                    <i class="fas fa-inbox" style="font-size: 40px; margin-bottom: 10px; display: block; color: #ddd;"></i>
                    هیچ آماری ثبت نشده است
                </td>
            </tr>
        `;
    } else {
        rations.forEach((ration, index) => {
            const user = users.find(u => u.username === ration.username);
            const submitDate = new Date(ration.submissionDate);
            
            reportHTML += `
                <tr>
                    <td>${index + 1}</td>
                    <td>${user ? user.fullName : 'نامشخص'}</td>
                    <td><strong>${ration.username}</strong></td>
                    <td>${ration.dormNumber || '-'}</td>
                    <td>${user ? user.department : '-'}</td>
                    <td>${ration.breakfastWeekdays || '-'}</td>
                    <td>${ration.thursday || '-'}</td>
                    <td>${ration.friday || '-'}</td>
                    <td>${submitDate.toLocaleDateString('fa-IR')}</td>
                    <td>
                        <button onclick="viewRationDetails('${ration.username}')" class="btn-small">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button onclick="editRationData('${ration.username}')" class="btn-small">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button onclick="deleteRationRecord('${ration.username}')" class="btn-small danger">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        });
    }
    
    reportHTML += `
                    </tbody>
                </table>
            </div>
            
            <div style="margin-top: 20px;">
                <h4><i class="fas fa-chart-pie"></i> نمودار آمار ثبت</h4>
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                    <div style="display: flex; align-items: center; height: 30px; background: #e0e0e0; border-radius: 15px; overflow: hidden; margin-bottom: 10px;">
                        <div style="width: ${submissionRate}%; height: 100%; background: linear-gradient(to right, #27ae60, #2ecc71);"></div>
                    </div>
                    <div style="display: flex; justify-content: space-between; font-size: 12px; color: #666;">
                        <div>ثبت‌شده (${submissionRate}%)</div>
                        <div>ثبت‌نشده (${100 - submissionRate}%)</div>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
            .stat-card-small {
                padding: 15px;
                border-radius: 8px;
                text-align: center;
            }
            
            .stat-value-small {
                font-size: 24px;
                font-weight: bold;
                margin-bottom: 5px;
            }
            
            .stat-label-small {
                font-size: 12px;
                color: #666;
            }
            
            .btn-small {
                padding: 5px 10px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                font-size: 12px;
                margin: 2px;
            }
            
            .btn-small.danger {
                background: #e74c3c;
                color: white;
            }
        </style>
    `;
    
    document.getElementById('adminContent').innerHTML = reportHTML;
}

// ==================== مدیریت تعیین مهلت ====================
function setRationDeadline() {
    if (!checkPermission('admin')) return;
    
    const currentDeadline = localStorage.getItem('rationDeadline') ? new Date(JSON.parse(localStorage.getItem('rationDeadline'))) : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    
    const formHTML = `
        <div class="card">
            <h3><i class="fas fa-clock"></i> تعیین مهلت ثبت آمار جیره</h3>
            
            <div style="margin-bottom: 20px; padding: 15px; background: #e8f4fc; border-radius: 8px;">
                <p><strong><i class="fas fa-calendar"></i> مهلت فعلی:</strong> ${currentDeadline.toLocaleDateString('fa-IR')} ساعت ${currentDeadline.toLocaleTimeString('fa-IR', {hour: '2-digit', minute:'2-digit'})}</p>
                <p><strong><i class="fas fa-info-circle"></i> وضعیت:</strong> ${new Date() > currentDeadline ? '❌ مهلت به پایان رسیده' : '✅ فعال'}</p>
            </div>
            
            <form id="deadlineForm">
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                    <div class="input-group">
                        <label for="deadlineDate"><i class="fas fa-calendar-day"></i> تاریخ پایان مهلت</label>
                        <input type="date" id="deadlineDate" value="${currentDeadline.toISOString().split('T')[0]}" required>
                    </div>
                    
                    <div class="input-group">
                        <label for="deadlineTime"><i class="fas fa-clock"></i> ساعت پایان مهلت</label>
                        <input type="time" id="deadlineTime" value="${currentDeadline.toTimeString().split(' ')[0].substring(0,5)}" required>
                    </div>
                </div>
                
                <div style="margin-top: 20px;">
                    <label for="deadlineMessage"><i class="fas fa-comment-alt"></i> پیام همراه (اختیاری)</label>
                    <textarea id="deadlineMessage" rows="3" placeholder="پیامی که به کاربران نمایش داده می‌شود..."></textarea>
                </div>
                
                <div style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                    <button type="submit" class="btn-success">
                        <i class="fas fa-save"></i> ثبت مهلت جدید
                    </button>
                    <button type="button" onclick="extendDeadline(24)" class="btn-primary">
                        <i class="fas fa-plus-circle"></i> افزایش ۲۴ ساعت
                    </button>
                    <button type="button" onclick="extendDeadline(72)" class="btn-primary">
                        <i class="fas fa-plus-circle"></i> افزایش ۷۲ ساعت
                    </button>
                    <button type="button" onclick="loadAdminPanel()" class="btn-secondary">
                        <i class="fas fa-times"></i> انصراف
                    </button>
                </div>
            </form>
        </div>
    `;
    
    document.getElementById('adminContent').innerHTML = formHTML;
    
    document.getElementById('deadlineForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const date = document.getElementById('deadlineDate').value;
        const time = document.getElementById('deadlineTime').value;
        const message = document.getElementById('deadlineMessage').value;
        
        const deadline = new Date(`${date}T${time}`);
        
        if (deadline < new Date()) {
            if (!confirm('⚠️ تاریخ انتخابی گذشته است. آیا مطمئن هستید؟')) {
                return;
            }
        }
        
        localStorage.setItem('rationDeadline', JSON.stringify(deadline));
        
        if (message.trim()) {
            localStorage.setItem('deadlineMessage', message);
        }
        
        addAdminLog(`مهلت آمار جیره به ${deadline.toLocaleDateString('fa-IR')} ساعت ${deadline.toLocaleTimeString('fa-IR', {hour: '2-digit', minute:'2-digit'})} تنظیم شد`);
        
        showAdminMessage('✅ مهلت جدید با موفقیت ثبت شد', 'success');
        
        setTimeout(() => {
            setRationDeadline();
        }, 1500);
    });
}

// افزایش مهلت
function extendDeadline(hours) {
    if (!checkPermission('admin')) return;
    
    const currentDeadline = localStorage.getItem('rationDeadline') ? 
        new Date(JSON.parse(localStorage.getItem('rationDeadline'))) : 
        new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    
    currentDeadline.setHours(currentDeadline.getHours() + hours);
    localStorage.setItem('rationDeadline', JSON.stringify(currentDeadline));
    
    addAdminLog(`مهلت آمار جیره ${hours} ساعت تمدید شد`);
    showAdminMessage(`✅ مهلت ${hours} ساعت تمدید شد`, 'success');
    
    setTimeout(() => {
        setRationDeadline();
    }, 1000);
}

// ==================== نمایش پیام در پنل ادمین ====================
function showAdminMessage(message, type = 'info') {
    const messagesDiv = document.getElementById('adminMessages');
    if (!messagesDiv) return;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.style.cssText = `
        padding: 12px 15px;
        margin: 10px 0;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 10px;
        animation: slideIn 0.3s ease-out;
    `;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        info: 'fa-info-circle',
        warning: 'fa-exclamation-triangle'
    };
    
    const colors = {
        success: '#d4edda',
        error: '#f8d7da',
        info: '#d1ecf1',
        warning: '#fff3cd'
    };
    
    const textColors = {
        success: '#155724',
        error: '#721c24',
        info: '#0c5460',
        warning: '#856404'
    };
    
    messageDiv.innerHTML = `
        <i class="fas ${icons[type]}" style="color: ${textColors[type]};"></i>
        <span style="color: ${textColors[type]};">${message}</span>
    `;
    
    messageDiv.style.background = colors[type];
    messageDiv.style.border = `1px solid ${type === 'success' ? '#c3e6cb' : type === 'error' ? '#f5c6cb' : type === 'info' ? '#bee5eb' : '#ffeaa7'}`;
    
    messagesDiv.appendChild(messageDiv);
    
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.style.opacity = '0';
            messageDiv.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (messageDiv.parentNode) {
                    messageDiv.remove();
                }
            }, 300);
        }
    }, 5000);
}

// ==================== اضافه کردن لاگ ====================
function addAdminLog(action) {
    const logs = JSON.parse(localStorage.getItem('adminLogs') || '[]');
    const user = getCurrentUser();
    
    const logEntry = {
        id: Date.now(),
        action: action,
        admin: user ? user.username : 'system',
        adminName: user ? user.fullName : 'سیستم',
        timestamp: new Date().toISOString(),
        ip: 'local'
    };
    
    logs.push(logEntry);
    
    // نگهداری فقط ۱۰۰۰ لاگ آخر
    if (logs.length > 1000) {
        logs.splice(0, logs.length - 1000);
    }
    
    localStorage.setItem('adminLogs', JSON.stringify(logs));
}

// ==================== پاک‌سازی کش سیستم ====================
function clearCache() {
    if (!checkPermission('admin')) return;
    
    if (!confirm('آیا می‌خواهید کش سیستم پاک شود؟ این عمل داده‌ها را پاک نمی‌کند.')) {
        return;
    }
    
    // پاک‌سازی فقط داده‌های کش موقت
    const tempData = [
        'tempData',
        'cache',
        'sessionData',
        'notificationCache'
    ];
    
    tempData.forEach(key => {
        localStorage.removeItem(key);
    });
    
    addAdminLog('کش سیستم پاک شد');
    showAdminMessage('✅ کش سیستم با موفقیت پاک شد', 'success');
}

// ==================== تأیید ریست سیستم ====================
function resetSystemConfirm() {
    if (!checkPermission('admin')) return;
    
    if (!confirm('⚠️ هشدار! این عمل تمام داده‌های سیستم را پاک می‌کند. آیا مطمئن هستید؟')) {
        return;
    }
    
    if (!confirm('آیا واقعاً مطمئن هستید؟ این عمل قابل بازگشت نیست و تمام اطلاعات کاربران، آمارها و تنظیمات پاک می‌شود!')) {
        return;
    }
    
    // حذف تمام داده‌ها
    localStorage.clear();
    
    // بازگردانی کاربر ادمین اصلی
    const adminUser = {
        id: 1,
        fullName: "مدیر سیستم",
        username: "403825663",
        password: "11633611006311",
        dormNumber: "0",
        role: "admin",
        department: "مدیریت",
        isActive: true,
        createdAt: new Date().toISOString()
    };
    
    localStorage.setItem('users', JSON.stringify([adminUser]));
    localStorage.setItem('currentUser', JSON.stringify(adminUser));
    
    // تنظیمات اولیه
    const initialSettings = {
        systemName: "گروهان شهید توکلی",
        version: "1.8.4",
        lastBackup: null,
        initializedAt: new Date().toISOString()
    };
    
    localStorage.setItem('systemSettings', JSON.stringify(initialSettings));
    
    addAdminLog('سیستم به حالت اولیه بازگردانی شد');
    showAdminMessage('✅ سیستم با موفقیت ریست شد. صفحه در حال بازنگاری است...', 'success');
    
    setTimeout(() => {
        window.location.href = '../index.html';
    }, 2000);
}

// ==================== توابع در حال توسعه ====================
function manageSecretaryAccess() {
    showAdminMessage('این بخش به زودی در صفحه تنظیمات سیستم اضافه خواهد شد', 'info');
}

function exportUsersToCSV() {
    showAdminMessage('خروجی CSV در حال توسعه است', 'info');
}

function exportRationData() {
    showAdminMessage('خروجی اکسل در حال توسعه است', 'info');
}

function sendReminders() {
    showAdminMessage('سیستم ارسال یادآوری در حال توسعه است', 'info');
}

function viewRationDetails(username) {
    showAdminMessage('مشاهده جزئیات آمار در صفحه آمار جیره در دسترس است', 'info');
}

function editRationData(username) {
    showAdminMessage('ویرایش آمار در صفحه آمار جیره در دسترس است', 'info');
}

function deleteRationRecord(username) {
    showAdminMessage('حذف آمار در صفحه آمار جیره در دسترس است', 'info');
}

function showUserActivityReport() {
    showAdminMessage('گزارش فعالیت کاربران در حال توسعه است', 'info');
}

function showManualAssignment() {
    showAdminMessage('توزیع دستی در صفحه خوابگاه‌ها در دسترس است', 'info');
}

function clearDormAssignments() {
    if (!checkPermission('admin')) return;
    
    if (!confirm('آیا می‌خواهید تمام تخصیص‌های خوابگاه پاک شوند؟')) {
        return;
    }
    
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    users.forEach(user => {
        user.dormNumber = '0';
    });
    
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('dorms', JSON.stringify({}));
    
    addAdminLog('تمام تخصیص‌های خوابگاه پاک شد');
    showAdminMessage('✅ تخصیص‌های خوابگاه پاک شدند', 'success');
    
    setTimeout(() => {
        showDormManagement();
    }, 1000);
}

function addUserToDorm(dormNumber, username, fullName, department) {
    let dorms = JSON.parse(localStorage.getItem('dorms') || '{}');
    const dormKey = `dorm${dormNumber}`;
    
    if (!dorms[dormKey]) {
        dorms[dormKey] = [];
    }
    
    // بررسی عدم وجود تکراری
    if (!dorms[dormKey].some(u => u.username === username)) {
        dorms[dormKey].push({
            username: username,
            fullName: fullName,
            department: department,
            assignedAt: new Date().toISOString()
        });
        
        localStorage.setItem('dorms', JSON.stringify(dorms));
    }
}

// ==================== بارگذاری خودکار پنل ادمین ====================
document.addEventListener('DOMContentLoaded', function() {
    // اگر در صفحه admin.html هستیم، پنل ادمین را بارگذاری کن
    if (window.location.pathname.includes('admin.html')) {
        loadAdminPanel();
    }
    
    // یا اگر در صفحه‌ای هستیم که نیاز به توابع ادمین دارد
    const currentUser = getCurrentUser();
    if (currentUser && currentUser.role === 'admin') {
        console.log('👑 پنل مدیریت بارگذاری شد');
    }
});

// ==================== استایل‌های CSS ====================
const adminStyles = `
    <style>
        .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            cursor: pointer;
            transition: all 0.3s;
            border: 2px solid transparent;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            border-color: #3498db;
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.2);
        }
        
        .stat-card i {
            font-size: 30px;
            color: #3498db;
            margin-bottom: 10px;
        }
        
        .stat-value {
            font-size: 24px;
            font-weight: bold;
            margin: 10px 0;
            color: #2c3e50;
        }
        
        .stat-label {
            font-size: 14px;
            color: #7f8c8d;
        }
        
        .card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        
        .card h3 {
            margin-bottom: 15px;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .input-group {
            margin-bottom: 15px;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .input-group input,
        .input-group select,
        .input-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            font-size: 14px;
        }
        
        .table-container {
            overflow-x: auto;
            margin-top: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .content-header {
            background: linear-gradient(to right, #2c3e50, #34495e);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .content-header h1 {
            margin-bottom: 5px;
        }
        
        .content-header p {
            opacity: 0.9;
            font-size: 14px;
        }
    </style>
`;

// اضافه کردن استایل‌ها به صفحه
document.head.insertAdjacentHTML('beforeend', adminStyles);