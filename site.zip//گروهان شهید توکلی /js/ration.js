// ==================== مدیریت آمار جیره ====================

// ساختار داده‌های آمار جیره:
/*
{
  id: number,                    // شناسه منحصر به فرد
  username: string,              // نام کاربری
  fullName: string,              // نام کامل کاربر
  dormNumber: string,            // شماره خوابگاه
  weekNumber: number,            // شماره هفته
  breakfastDays: array,          // روزهایی که صبحانه خورده ["شنبه", "یکشنبه", ...]
  breakfastCount: number,        // تعداد روزهای صبحانه
  thursdayBreakfast: string,     // صبحانه پنج‌شنبه: "خورده"/"نخورده"
  thursdayLunch: string,         // ناهار پنج‌شنبه: "خورده"/"نخورده"
  thursdayDinner: string,        // شام پنج‌شنبه: "خورده"/"نخورده"
  fridayBreakfast: string,       // صبحانه جمعه: "خورده"/"نخورده"
  fridayLunch: string,           // ناهار جمعه: "خورده"/"نخورده"
  fridayDinner: string,          // شام جمعه: "خورده"/"نخورده"
  submissionDate: string,        // تاریخ ثبت (ISO string)
  status: string,                // وضعیت: "ثبت شده"
  notes: string                  // توضیحات اختیاری
}
*/

// ==================== توابع مدیریت داده‌ها ====================

// مقداردهی اولیه داده‌های آمار جیره
function initializeRations() {
    console.log("📊 مقداردهی اولیه داده‌های آمار جیره...");
    
    if (!localStorage.getItem('rations')) {
        localStorage.setItem('rations', JSON.stringify([]));
        console.log("✅ آرایه خالی آمار جیره ایجاد شد");
    }
    
    if (!localStorage.getItem('rationDeadline')) {
        const defaultDeadline = new Date();
        defaultDeadline.setDate(defaultDeadline.getDate() + 7);
        localStorage.setItem('rationDeadline', JSON.stringify(defaultDeadline));
        console.log("✅ مهلت پیش‌فرض تنظیم شد");
    }
    
    // ایجاد داده‌های نمونه برای تست (در حالت توسعه)
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        createSampleRations();
    }
}

// ایجاد داده‌های نمونه برای تست
function createSampleRations() {
    const rations = JSON.parse(localStorage.getItem('rations'));
    
    if (rations.length === 0) {
        const sampleRations = [
            {
                id: 1,
                username: "user1",
                fullName: "سرباز نمونه",
                dormNumber: "1",
                weekNumber: getCurrentWeekNumber(),
                breakfastDays: ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه"],
                breakfastCount: 4,
                thursdayBreakfast: "خورده",
                thursdayLunch: "خورده",
                thursdayDinner: "نخورده",
                fridayBreakfast: "خورده",
                fridayLunch: "خورده",
                fridayDinner: "خورده",
                submissionDate: new Date().toISOString(),
                status: "ثبت شده",
                notes: "نمونه اول"
            },
            {
                id: 2,
                username: "user1",
                fullName: "سرباز نمونه",
                dormNumber: "1",
                weekNumber: getCurrentWeekNumber() - 1,
                breakfastDays: ["شنبه", "دوشنبه", "چهارشنبه"],
                breakfastCount: 3,
                thursdayBreakfast: "خورده",
                thursdayLunch: "نخورده",
                thursdayDinner: "خورده",
                fridayBreakfast: "خورده",
                fridayLunch: "خورده",
                fridayDinner: "نخورده",
                submissionDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
                status: "ثبت شده",
                notes: "نمونه هفته گذشته"
            }
        ];
        
        localStorage.setItem('rations', JSON.stringify(sampleRations));
        console.log("📝 داده‌های نمونه آمار جیره ایجاد شد");
    }
}

// ==================== توابع اصلی ====================

// دریافت شماره هفته جاری
function getCurrentWeekNumber() {
    const now = new Date();
    const startOfYear = new Date(now.getFullYear(), 0, 1);
    const pastDaysOfYear = (now - startOfYear) / 86400000;
    return Math.ceil((pastDaysOfYear + startOfYear.getDay() + 1) / 7);
}

// دریافت آمار جیره کاربر برای هفته جاری
function getUserCurrentRation(username) {
    const rations = JSON.parse(localStorage.getItem('rations') || '[]');
    const currentWeek = getCurrentWeekNumber();
    
    return rations.find(r => 
        r.username === username && 
        r.weekNumber === currentWeek
    );
}

// دریافت تمام آمارهای یک کاربر
function getUserAllRations(username) {
    const rations = JSON.parse(localStorage.getItem('rations') || '[]');
    return rations.filter(r => r.username === username);
}

// بررسی آیا کاربر برای هفته جاری ثبت کرده
function hasUserSubmittedCurrentWeek(username) {
    return !!getUserCurrentRation(username);
}

// بررسی مهلت ثبت
function isRationDeadlinePassed() {
    const deadline = JSON.parse(localStorage.getItem('rationDeadline'));
    if (!deadline) return false;
    
    const now = new Date();
    const deadlineDate = new Date(deadline);
    
    return now > deadlineDate;
}

// دریافت روزهای باقی‌مانده تا پایان مهلت
function getDaysUntilDeadline() {
    const deadline = JSON.parse(localStorage.getItem('rationDeadline'));
    if (!deadline) return null;
    
    const now = new Date();
    const deadlineDate = new Date(deadline);
    const timeDiff = deadlineDate - now;
    
    return Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
}

// ==================== CRUD عملیات ====================

// ثبت آمار جیره جدید
function submitRation(rationData) {
    console.log("📤 ثبت آمار جیره جدید...", rationData);
    
    // اعتبارسنجی داده‌ها
    if (!validateRationData(rationData)) {
        return {
            success: false,
            message: "داده‌های وارد شده معتبر نیستند"
        };
    }
    
    // بررسی مهلت
    if (isRationDeadlinePassed()) {
        return {
            success: false,
            message: "مهلت ثبت آمار جیره به پایان رسیده است"
        };
    }
    
    const rations = JSON.parse(localStorage.getItem('rations') || '[]');
    const currentWeek = getCurrentWeekNumber();
    
    // بررسی وجود ثبت قبلی برای همین هفته
    const existingRationIndex = rations.findIndex(r => 
        r.username === rationData.username && 
        r.weekNumber === currentWeek
    );
    
    // آماده‌سازی داده‌های نهایی
    const finalRationData = {
        ...rationData,
        id: Date.now(),
        weekNumber: currentWeek,
        breakfastCount: rationData.breakfastDays.length,
        submissionDate: new Date().toISOString(),
        status: "ثبت شده"
    };
    
    if (existingRationIndex !== -1) {
        // به‌روزرسانی ثبت موجود
        finalRationData.id = rations[existingRationIndex].id;
        rations[existingRationIndex] = finalRationData;
        console.log("🔄 آمار جیره به‌روزرسانی شد");
    } else {
        // اضافه کردن ثبت جدید
        rations.push(finalRationData);
        console.log("✅ آمار جیره جدید ثبت شد");
    }
    
    // ذخیره در localStorage
    localStorage.setItem('rations', JSON.stringify(rations));
    
    return {
        success: true,
        message: existingRationIndex !== -1 ? 
            "آمار جیره با موفقیت به‌روزرسانی شد" : 
            "آمار جیره با موفقیت ثبت شد",
        data: finalRationData
    };
}

// اعتبارسنجی داده‌های آمار جیره
function validateRationData(rationData) {
    const errors = [];
    
    if (!rationData.username) {
        errors.push("نام کاربری ضروری است");
    }
    
    if (!rationData.fullName) {
        errors.push("نام کامل ضروری است");
    }
    
    if (!rationData.dormNumber) {
        errors.push("شماره خوابگاه ضروری است");
    }
    
    if (!rationData.breakfastDays || !Array.isArray(rationData.breakfastDays)) {
        errors.push("روزهای صبحانه ضروری است");
    }
    
    const requiredFields = [
        'thursdayBreakfast', 'thursdayLunch', 'thursdayDinner',
        'fridayBreakfast', 'fridayLunch', 'fridayDinner'
    ];
    
    requiredFields.forEach(field => {
        if (!rationData[field]) {
            errors.push(`فیلد ${getFieldPersianName(field)} ضروری است`);
        }
    });
    
    if (errors.length > 0) {
        console.error("❌ خطاهای اعتبارسنجی:", errors);
        return false;
    }
    
    return true;
}

// نام فارسی فیلدها برای نمایش خطا
function getFieldPersianName(field) {
    const fieldNames = {
        thursdayBreakfast: "صبحانه پنج‌شنبه",
        thursdayLunch: "ناهار پنج‌شنبه",
        thursdayDinner: "شام پنج‌شنبه",
        fridayBreakfast: "صبحانه جمعه",
        fridayLunch: "ناهار جمعه",
        fridayDinner: "شام جمعه"
    };
    
    return fieldNames[field] || field;
}

// حذف آمار جیره
function deleteRation(rationId) {
    const rations = JSON.parse(localStorage.getItem('rations') || '[]');
    const initialLength = rations.length;
    
    const filteredRations = rations.filter(r => r.id !== rationId);
    
    if (filteredRations.length < initialLength) {
        localStorage.setItem('rations', JSON.stringify(filteredRations));
        console.log("🗑️ آمار جیره حذف شد:", rationId);
        return {
            success: true,
            message: "آمار جیره با موفقیت حذف شد"
        };
    } else {
        return {
            success: false,
            message: "آمار جیره یافت نشد"
        };
    }
}

// دریافت آمار جیره بر اساس شناسه
function getRationById(rationId) {
    const rations = JSON.parse(localStorage.getItem('rations') || '[]');
    return rations.find(r => r.id === rationId);
}

// ==================== توابع گزارش‌گیری ====================

// تعداد کل ثبت‌های یک کاربر
function getUserTotalSubmissions(username) {
    const userRations = getUserAllRations(username);
    return userRations.length;
}

// میانگین وعده‌های یک کاربر
function getUserAverageMeals(username) {
    const userRations = getUserAllRations(username);
    
    if (userRations.length === 0) return 0;
    
    let totalMeals = 0;
    userRations.forEach(ration => {
        // صبحانه روزهای عادی
        totalMeals += ration.breakfastCount || 0;
        
        // وعده‌های پنج‌شنبه
        if (ration.thursdayBreakfast === 'خورده') totalMeals++;
        if (ration.thursdayLunch === 'خورده') totalMeals++;
        if (ration.thursdayDinner === 'خورده') totalMeals++;
        
        // وعده‌های جمعه
        if (ration.fridayBreakfast === 'خورده') totalMeals++;
        if (ration.fridayLunch === 'خورده') totalMeals++;
        if (ration.fridayDinner === 'خورده') totalMeals++;
    });
    
    return (totalMeals / userRations.length).toFixed(1);
}

// تاریخ آخرین ثبت کاربر
function getUserLastSubmissionDate(username) {
    const userRations = getUserAllRations(username);
    
    if (userRations.length === 0) return null;
    
    const lastRation = userRations.reduce((latest, current) => {
        return new Date(current.submissionDate) > new Date(latest.submissionDate) ? current : latest;
    });
    
    return new Date(lastRation.submissionDate);
}

// آمار کلی گروهان
function getGroupRationStats() {
    const rations = JSON.parse(localStorage.getItem('rations') || '[]');
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const currentWeek = getCurrentWeekNumber();
    
    const totalUsers = users.filter(u => u.role === 'user').length;
    const submittedThisWeek = rations.filter(r => r.weekNumber === currentWeek).length;
    const submissionRate = totalUsers > 0 ? Math.round((submittedThisWeek / totalUsers) * 100) : 0;
    
    return {
        totalUsers,
        submittedThisWeek,
        notSubmittedThisWeek: totalUsers - submittedThisWeek,
        submissionRate,
        currentWeek
    };
}

// ==================== مدیریت مهلت ثبت ====================

// تنظیم مهلت جدید
function setRationDeadline(dateString) {
    const deadline = new Date(dateString);
    
    if (isNaN(deadline.getTime())) {
        return {
            success: false,
            message: "تاریخ وارد شده معتبر نیست"
        };
    }
    
    localStorage.setItem('rationDeadline', JSON.stringify(deadline));
    console.log("✅ مهلت جدید تنظیم شد:", deadline);
    
    return {
        success: true,
        message: `مهلت ثبت تا ${deadline.toLocaleDateString('fa-IR')} تنظیم شد`
    };
}

// دریافت مهلت فعلی
function getCurrentDeadline() {
    const deadline = JSON.parse(localStorage.getItem('rationDeadline'));
    return deadline ? new Date(deadline) : null;
}

// فرمت کردن تاریخ مهلت برای نمایش
function formatDeadlineForDisplay() {
    const deadline = getCurrentDeadline();
    if (!deadline) return "مهلتی تنظیم نشده";
    
    const now = new Date();
    const isPassed = now > deadline;
    
    const persianDate = deadline.toLocaleDateString('fa-IR');
    const time = deadline.toLocaleTimeString('fa-IR', {hour: '2-digit', minute:'2-digit'});
    
    if (isPassed) {
        return `⏰ مهلت به پایان رسیده (${persianDate} ساعت ${time})`;
    } else {
        const daysLeft = getDaysUntilDeadline();
        return `⏳ ${daysLeft} روز تا پایان مهلت (${persianDate} ساعت ${time})`;
    }
}

// ==================== توابع کمکی برای نمایش ====================

// تولید HTML برای تاریخچه ثبت‌ها
function generateRationHistoryHTML(username) {
    const userRations = getUserAllRations(username);
    
    if (userRations.length === 0) {
        return `
            <div class="empty-state">
                <i class="fas fa-clipboard-list"></i>
                <h3>هنوز هیچ آمار جیره‌ای ثبت نکرده‌اید</h3>
                <p>اولین ثبت خود را انجام دهید تا اینجا نمایش داده شود.</p>
            </div>
        `;
    }
    
    let html = `
        <div class="table-container">
            <table class="history-table">
                <thead>
                    <tr>
                        <th>هفته</th>
                        <th>تاریخ ثبت</th>
                        <th>صبحانه روزهای عادی</th>
                        <th>پنج‌شنبه</th>
                        <th>جمعه</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    // مرتب سازی بر اساس تاریخ (جدیدترین اول)
    userRations.sort((a, b) => new Date(b.submissionDate) - new Date(a.submissionDate));
    
    userRations.forEach(ration => {
        const submitDate = new Date(ration.submissionDate);
        const isCurrentWeek = ration.weekNumber === getCurrentWeekNumber();
        const canEdit = isCurrentWeek && !isRationDeadlinePassed();
        
        html += `
            <tr>
                <td><strong>هفته ${ration.weekNumber}</strong> ${isCurrentWeek ? '(جاری)' : ''}</td>
                <td>${submitDate.toLocaleDateString('fa-IR')}<br>
                    <small>${submitDate.toLocaleTimeString('fa-IR', {hour: '2-digit', minute:'2-digit'})}</small>
                </td>
                <td>
                    ${ration.breakfastCount} روز
                    ${ration.breakfastDays.length > 0 ? 
                        `<br><small>(${ration.breakfastDays.join('، ')})</small>` : 
                        ''
                    }
                </td>
                <td>
                    ${ration.thursdayBreakfast ? `<span class="meal-tag">صبح: ${ration.thursdayBreakfast}</span>` : ''}
                    ${ration.thursdayLunch ? `<span class="meal-tag">نهار: ${ration.thursdayLunch}</span>` : ''}
                    ${ration.thursdayDinner ? `<span class="meal-tag">شام: ${ration.thursdayDinner}</span>` : ''}
                </td>
                <td>
                    ${ration.fridayBreakfast ? `<span class="meal-tag">صبح: ${ration.fridayBreakfast}</span>` : ''}
                    ${ration.fridayLunch ? `<span class="meal-tag">نهار: ${ration.fridayLunch}</span>` : ''}
                    ${ration.fridayDinner ? `<span class="meal-tag">شام: ${ration.fridayDinner}</span>` : ''}
                </td>
                <td>
                    <span class="status-badge status-submitted">
                        <i class="fas fa-check-circle"></i>
                        ${ration.status}
                    </span>
                </td>
                <td>
                    ${canEdit ? 
                        `<button onclick="editRation(${ration.id})" class="btn-small">
                            <i class="fas fa-edit"></i> ویرایش
                        </button>` : 
                        '<span style="color: #95a5a6; font-size: 0.9rem;">غیرقابل ویرایش</span>'
                    }
                </td>
            </tr>
        `;
    });
    
    html += `
                </tbody>
            </table>
        </div>
    `;
    
    return html;
}

// تولید HTML برای آمار خلاصه
function generateRationStatsHTML(username) {
    const totalSubmissions = getUserTotalSubmissions(username);
    const averageMeals = getUserAverageMeals(username);
    const lastSubmission = getUserLastSubmissionDate(username);
    
    let lastSubmissionText = "ثبت نشده";
    if (lastSubmission) {
        const now = new Date();
        const diffTime = now - lastSubmission;
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 0) lastSubmissionText = "امروز";
        else if (diffDays === 1) lastSubmissionText = "دیروز";
        else lastSubmissionText = `${diffDays} روز پیش`;
    }
    
    return `
        <div class="stats-summary">
            <div class="stat-card">
                <i class="fas fa-calendar-check" style="color: #27ae60; font-size: 30px;"></i>
                <div class="stat-value">${totalSubmissions}</div>
                <div>تعداد ثبت‌ها</div>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-utensils" style="color: #3498db; font-size: 30px;"></i>
                <div class="stat-value">${averageMeals}</div>
                <div>میانگین وعده‌ها</div>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-clock" style="color: #f39c12; font-size: 30px;"></i>
                <div class="stat-value">${lastSubmissionText}</div>
                <div>آخرین ثبت</div>
            </div>
        </div>
    `;
}

// ==================== مدیریت فرم ====================

// پر کردن فرم با داده‌های موجود
function fillFormWithRationData(rationData) {
    if (!rationData) return;
    
    // پر کردن روزهای صبحانه
    if (rationData.breakfastDays && Array.isArray(rationData.breakfastDays)) {
        const checkboxes = document.querySelectorAll('input[name="breakfastDays"]');
        checkboxes.forEach(checkbox => {
            checkbox.checked = rationData.breakfastDays.includes(checkbox.value);
        });
    }
    
    // پر کردن فیلدهای پنج‌شنبه
    if (rationData.thursdayBreakfast) {
        document.getElementById('thursdayBreakfast').value = rationData.thursdayBreakfast;
    }
    if (rationData.thursdayLunch) {
        document.getElementById('thursdayLunch').value = rationData.thursdayLunch;
    }
    if (rationData.thursdayDinner) {
        document.getElementById('thursdayDinner').value = rationData.thursdayDinner;
    }
    
    // پر کردن فیلدهای جمعه
    if (rationData.fridayBreakfast) {
        document.getElementById('fridayBreakfast').value = rationData.fridayBreakfast;
    }
    if (rationData.fridayLunch) {
        document.getElementById('fridayLunch').value = rationData.fridayLunch;
    }
    if (rationData.fridayDinner) {
        document.getElementById('fridayDinner').value = rationData.fridayDinner;
    }
}

// جمع‌آوری داده‌های فرم
function collectFormData() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) return null;
    
    // جمع‌آوری روزهای صبحانه
    const breakfastCheckboxes = document.querySelectorAll('input[name="breakfastDays"]:checked');
    const breakfastDays = Array.from(breakfastCheckboxes).map(cb => cb.value);
    
    return {
        username: currentUser.username,
        fullName: currentUser.fullName,
        dormNumber: currentUser.dormNumber,
        breakfastDays: breakfastDays,
        thursdayBreakfast: document.getElementById('thursdayBreakfast').value,
        thursdayLunch: document.getElementById('thursdayLunch').value,
        thursdayDinner: document.getElementById('thursdayDinner').value,
        fridayBreakfast: document.getElementById('fridayBreakfast').value,
        fridayLunch: document.getElementById('fridayLunch').value,
        fridayDinner: document.getElementById('fridayDinner').value,
        notes: document.getElementById('rationNotes')?.value || ''
    };
}

// ==================== مقداردهی اولیه ====================
document.addEventListener('DOMContentLoaded', function() {
    console.log("📊 ماژول آمار جیره بارگذاری شد");
    initializeRations();
});

// ==================== صادر کردن توابع برای استفاده در فایل‌های دیگر ====================
if (typeof window !== 'undefined') {
    window.rationManager = {
        initializeRations,
        getUserCurrentRation,
        getUserAllRations,
        hasUserSubmittedCurrentWeek,
        isRationDeadlinePassed,
        getDaysUntilDeadline,
        submitRation,
        deleteRation,
        getRationById,
        getGroupRationStats,
        setRationDeadline,
        getCurrentDeadline,
        formatDeadlineForDisplay,
        generateRationHistoryHTML,
        generateRationStatsHTML,
        fillFormWithRationData,
        collectFormData,
        getCurrentWeekNumber,
        validateRationData
    };
}